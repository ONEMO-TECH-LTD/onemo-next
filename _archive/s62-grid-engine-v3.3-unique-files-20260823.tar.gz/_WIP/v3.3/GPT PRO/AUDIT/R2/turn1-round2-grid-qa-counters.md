# Turn-1 review, Round 2 — Grid QA counters to Meta

## Verdict on Meta's headline

Meta's **ACCEPT as substantially conforming** gives too much credit to checklist coverage. The documents do trace all ten feedback-pack items, but two load-bearing contracts are not executable as written: registration/mechanical selection is internally wrong and computationally incomplete, and Hold A is circular through `PD-30`. The correct state remains **REVISE before Dan receives the register**.

## Counters to Meta D1-D5

### D1 survives, but Meta's requested fix is insufficient

Agreed: canonical-first registration contradicts `PD-28`, and changing `PD-15` alone cannot repair the solver order.

But “mechanical quality must choose the registration” is still prose, not an algorithm. The criteria in `02 §11.2` vary over a continuous feasible-translation region. The solver must define how it obtains a certified lexicographic optimum rather than merely evaluating an unspecified set of registrations. The amended contract must make `(size, frame, pattern, registration)` the joint candidate and require either:

- certified criterion extrema/argmin regions over the feasible region; or
- a proven finite critical-point set with bounded refinement and exact revalidation.

Canonical proximity, X and Y may break ties only inside the mechanically equivalent optimum set. Without this addition the proposed amendment fixes ordering but leaves implementers to invent the search.

### D2 fails as stated; a different Hold A defect survives

`01 §14` does not authorize a seven-decision compute gate. It says Compute is ready only when those decisions are resolved **and** “Hold A clears.” That is consistent with `00 §1.2`'s all-stop gate. GPT's later Gate A/B/C model is a new cadence proposal, not a correction already authorized by Dan's instruction to stop after Turn 1 and present the consolidated register.

There is, however, a real circularity Meta missed: `PD-30` is `UNRESOLVED` until the backend probe chooses the backend, while Hold A prohibits the backend probe until every `UNRESOLVED` row is resolved. The smallest repair is not a three-gate rewrite. Move backend selection out of the product-decision register into an engineering-gate record, then let the existing Hold A clear before the bounded probe. A split gate may be presented to Dan as an optional cadence amendment, never silently adopted in the specs.

### D3 survives

Add `PD-38 UNRESOLVED`: whether the 12 mm rule is the required post-tolerance clearance or a nominal design radius whose manufacturing variance is accepted elsewhere. The Compute contract should continue accepting the caller/profile radius; the product profile owns the approved effective radius. Do not seed the decision with invented tolerance values.

### D4 partly survives

- `PD-04` is misclassified. In the fresh transcript, 96 mm appears in GPT's opening carry-over recap, not in Dan's fresh direct statements. It cannot remain `LOCKED_FROM_DAN`; its existence should be unresolved or traced to a verified live product source.
- The objection to `PD-13` and `PD-32` fails under the document's explicit taxonomy: `LOCKED_FROM_DAN` means directly stated **or adopted by Dan from the review pack**. Dan explicitly directed GPT to revise using the complete feedback. Their source columns already distinguish `DAN-ADOPTION-01` and `TEAM-SPEC-01` from direct statements. Do not invent a fourth status after Dan required exactly three classifications. If clarity is still desired, add an authority-basis field (`DIRECT` / `ADOPTED`) without changing status.

### D5 survives as a necessity reduction

The local §0 tables are dependency views, not literally independent registers, but repeating mutable statuses adds no value and can drift. Keep the PD IDs and local treatment; remove the duplicated status column and state that status is read only from `00 §15`.

## QA findings Meta did not cover

### Artifact identity must name both engines

The canonical input in `00 §5.1` accepts one `engineArtifactHash`, but the final `ManufacturingSpec` records separate Compute and Logic artifact hashes. Output depends on both. The deterministic identity must be:

`hash(canonicalGeometryInputs + profileHash + computeArtifactHash + logicArtifactHash)`

with timestamps excluded. A singular ambiguous engine hash is insufficient.

### `PD-30` is not a product decision

Backend choice is a measured engineering result subject to the approved correctness/performance gates, not a product value for Dan to invent or approve. Moving it out of §15 both repairs the Hold A deadlock and preserves the product/engineering authority boundary.

### Two cross-references are wrong

- `00 §5.3` attributes the holes/disconnected consequence to `PD-21`; it is `PD-22`.
- `00 §7.2` attributes registration order to `PD-14`; it is `PD-15`.

### Exact canon geometry remains a hard dependency

`PD-29` must remain unresolved until Dan approves the actual Batwoman outline. GPT-authored geometry may be proposed as a fixture candidate but cannot become canon or outvote the screenshots/walkthrough.

## Strongest counter to this position

A backend-selection row could be retained as an `UNRESOLVED` engineering placeholder if Hold A explicitly exempted measured engineering outcomes. That is mechanically possible. It is still worse than moving it: the register is defined as a product-decision surface for Dan, and exemption language would preserve the category error while adding another gate exception.

## Necessity / sufficiency

**Necessity: shrink the amendment.** Do not import GPT's full Gate A/B/C redesign as though it were an authorized correction; repair the actual `PD-30` deadlock, remove repeated statuses, and touch only the defective contracts and references.

**Sufficiency: partial.** Meta's five-point request misses the continuous optimisation contract, two-engine identity, `PD-30` authority/deadlock, and two broken references. Add those before the correction request is complete.

— s62-grid-qa
