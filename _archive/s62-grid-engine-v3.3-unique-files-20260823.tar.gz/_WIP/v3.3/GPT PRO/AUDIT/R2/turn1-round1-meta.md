# Turn-1 review, Round 1 — s62-kai-meta independent verdict

Sources read in full, fresh 12:10 export only: `ChatGPT-Grid and Band Logic-20260815-1210.md` (5,270 lines; first 3,918 verified byte-identical to prior read, new tail read completely) + `DOCS/00-system-contract.md` (530) + `DOCS/01-compute-engine-spec.md` (815) + `DOCS/02-logic-engine-spec.md` (1,076). QA's round-1 file not read.

## Verdict

**ACCEPT the Turn-1 delivery as substantially conforming to the joint feedback pack — but REQUIRE one amendment round before the register goes to Dan for Hold A processing.** All 10 pack items are genuinely implemented in the documents; I traced each. The blocker is that GPT's *own post-delivery reflection* identified a real defect and two improvements that exist only as conversation prose — the canonical artifacts still carry the defective version. An internally inconsistent artifact set must not reach the approval desk.

## Strongest defects

### D1 — BLOCKER: the delivered registration order contradicts locked canon (PD-15 vs PD-28)

`00 §7.2` and `02 §8.5` specify canonical-if-feasible → nearest → X → Y, and the solver sequence (`02 §12.2` step 6.12) fixes each pattern's registration *before* mechanical criteria are computed (step 6.15). For Batwoman B1 the single-anchor feasible region is the whole safe core: if the bbox-centre position is legal in the chest, canonical-if-feasible selects it immediately and the mechanics never evaluate the head anchor — directly violating `PD-28` (`LOCKED_FROM_DAN`: B1 = upper/head anchor). The spec is internally inconsistent: a locked constraint is unsatisfiable under a proposed rule *and* a hard-coded solver order. GPT diagnosed this itself in the reflection ("mechanical quality must choose the registration; canonical proximity must only break ties") — correctly — but the DOCS were not amended. Note for the record: the flaw's seed phrasing ("nearest to canonical") originated in our own feedback pack; GPT's correction improves on our ask and must be folded into `00 §7.2`, `02 §8.5`, `02 §11.2` and solver steps 6.12–6.16.

### D2 — Internal inconsistency: what blocks the backend probe

`00 §1.2` (Hold A): "no backend probe … until Dan approves … EVERY `PROPOSED_FOR_DAN` and `UNRESOLVED` item." `01 §14`: the compute spec is implementation-ready when Dan resolves only seven PDs (14/15/25/26/27/31/35). Both cannot be true. GPT's reflection proposes the right fix (Gate A compute-critical / Gate B logic-profile / Gate C production) but, again, only in chat. The docs must pick one gate model; the split gate is the better one and lets the probe start without waiting on e.g. `PD-10` (board display) or `PD-34` (96mm usage).

### D3 — Missing decision row: tolerance-inflated verification radius

The reflection's final open question — does manufacturing verification use nominal 12.00mm or a radius inflated by cut tolerance + magnet-placement tolerance (e.g. 12.50mm effective) — appears in no spec and no PD row. This is a physical-product decision with direct geometric consequence (it shrinks every safe core and can change band outcomes), it belongs to Dan, and the register is the designated home for exactly this. Require a new `PD-38 UNRESOLVED` row plus a hook in `01 §5.5–5.6` (verification radius = caller value; profile decides nominal vs inflated).

### D4 — Status/traceability hygiene in the register (non-blocking, fix in same pass)

- `PD-04` (96mm population) is labeled `LOCKED_FROM_DAN` via `DAN-GRID-01 "Dan direct"` — but in the fresh transcript the 96mm lattice facts appear only in GPT's opening recap of prior context; Dan never restates them in this conversation. Consequence is low (usage is separately `UNRESOLVED` under PD-34), but "Dan direct" is a mislabel that weakens the register's whole authority model.
- `PD-13` and `PD-32` are labeled `LOCKED_FROM_DAN` with team-review sources (`TEAM-SPEC-01`, `DAN-ADOPTION-01`). Dan's "consider the feedback / revise using it" plausibly adopts them, but locked-by-adoption and locked-by-Dan's-own-words are different strengths of authority and should be visibly distinguished (e.g. `LOCKED_VIA_ADOPTION`) so Dan knows which rows are his sentences and which are ours he ratified wholesale.

### D5 — Minor: duplicated status tables risk drift

`01 §0` and `02 §0` restate PD statuses in local tables. The contract says §15 is the only register and others "reference these IDs rather than creating competing registers" — the restated status columns are competing copies that can silently desynchronise after amendments. Reduce to ID references, or mark the local tables non-authoritative.

## What is genuinely strong (credit)

Full pack compliance in the artifacts: three-status classification with per-value source traces; backend-neutral contract + bounded probe with correctness-disqualifies-first selection; Batwoman as locked black-box constraints with ten counterexamples and quantum-boundary fixtures; the conservative-approximation sandwich (C_{r+ε} ⊆ Ĉ ⊆ C_r) with `INDETERMINATE_WITHIN_TOLERANCE`, `FEASIBLE_BELOW_OUTPUT_QUANTUM`, and the corridor lower-dimensional-tangency case — a real mathematical contract, not prose; two-stage ManufacturingSpec with artifact-hash identity and timestamps outside the hash; module seams with ownership rules; declared gate re-baselining; and a real repo probe (engine scaffolded only — greenfield confirmed). New catches nobody ordered: `PD-36` (the "B1 is always possible" ambiguity) and `PD-37` (axis class = capacity, not compulsory frame — closer to Dan's intent than any prior text). The failure taxonomy is complete and machine-readable.

## Strongest self-counter

The D1 "blocker" can be argued away: PD-15 is `PROPOSED_FOR_DAN`, the register exists precisely so Dan can amend proposals, and GPT disclosed the defect in the same conversation cycle — so requiring a re-delivery round before Dan sees the register could be pure ceremony; Dan could simply approve PD-15 *as amended by the reflection* and the implementation would follow the amended row. That is a real option and cheaper. I hold the blocker anyway, on two grounds: (a) the solver sequence in `02 §12.2` hard-codes the collapse-then-evaluate order *outside* any PD row, so amending PD-15 alone does not repair the spec; (b) a register whose locked row (PD-28) is unsatisfiable under its proposed row (PD-15) presents Dan with a self-contradictory approval surface — the one thing the register exists to prevent. One amendment message costs a turn; an inconsistent approval costs a re-litigation later.

## Necessity / sufficiency

**Necessity: no unnecessary elements.** No code, no backend lock, no invented permissions matrix (PD-19 correctly refuses to invent), no fourth artifact; document length is the mandated spec-first depth and maps to pack requirements. Candidates I probed for bloat (the `canonical-point` module, the L-variant family, the failure taxonomy) each carry an independent seam or contract duty.

**Sufficiency: partial.** The pack is delivered in full *in the documents* with these gaps: mechanics-first registration exists only in chat (D1); the gate model is inconsistent and its fix exists only in chat (D2); the tolerance-inflation decision is absent from register and specs entirely (D3); register status hygiene (D4). CLEAR for Dan's approval pass only after one amendment round folds D1–D4 into the canonical artifacts.

## Proposed joint correction request (input to the merge)

One message to GPT Pro: (1) amend `00 §7.2`, `02 §8.5`, `02 §11.2`, `02 §12.2` to mechanics-first registration with canonical proximity as final tie-break, updating PD-15's proposed text to match; (2) replace the single Hold A with Gates A/B/C exactly as its reflection defined, reconciling `00 §1.2` with `01 §14`; (3) add `PD-38` (verification radius: nominal vs tolerance-inflated) as `UNRESOLVED` with the compute-side hook; (4) relabel PD-04/PD-13/PD-32 with honest authority classes and demote the §0 status tables to non-authoritative ID references; (5) redeliver the three files only — no other content changes, no code.

— s62-kai-meta
