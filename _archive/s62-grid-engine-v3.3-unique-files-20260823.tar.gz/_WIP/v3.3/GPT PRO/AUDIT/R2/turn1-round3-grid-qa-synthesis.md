# Turn-1 review, Round 3 — Grid QA synthesis

## Converged verdict

**REVISE, then present the register to Dan. No code and no backend probe.** Meta's “accept with mandatory amendment” and QA's “revise before approval” now mean the same operational thing. Checklist coverage is substantial, but the canonical artifacts are not yet a coherent approval or implementation surface.

## Findings that survived both lanes

1. **Registration and mechanics must be one optimisation problem.** Replace canonical-first collapse with joint `(size, frame, pattern, registration)` evaluation. The contract must define certified lexicographic optimisation over each continuous feasible set through criterion extrema/argmin regions or a proven finite critical-point set with bounded refinement and exact revalidation. Canonical proximity/X/Y operate only inside the mechanically equivalent optimum set. Add the connected-component B1 counterexample: one feasible component may include both chest-centre and the mechanically superior head anchor.
2. **Fix deterministic identity.** Canonical output identity depends on canonical geometry inputs, profile hash, Compute artifact hash and Logic artifact hash. Split the ambiguous singular `engineArtifactHash`; timestamps stay outside the hash. Compute-only evidence remains input + Compute artifact hash.
3. **Add the missing tolerance decision.** New `PD-38 UNRESOLVED`: decide whether 12 mm is minimum post-tolerance clearance or a nominal design value with manufacturing variance handled as accepted residual risk. Compute accepts the profile-provided effective radius; no tolerance numbers are invented.
4. **Remove the Hold A deadlock.** `PD-30` can be resolved only by the backend probe, while Hold A forbids that probe until every unresolved PD clears. Backend selection is a measured engineering outcome, so move it out of the product-decision register into an engineering gate governed by approved correctness/performance constraints.
5. **Repair traceability.** Reclassify `PD-04`: 96 mm is only in GPT's opening carry-over recap, not Dan's fresh statements. Preserve `PD-13/PD-32` as adopted locks under the document's declared taxonomy. Correct `00 §5.3` from PD-21 to PD-22 and `00 §7.2` from PD-14 to PD-15.
6. **Remove mutable register copies.** Local Compute/Logic dependency tables keep PD IDs and treatment only; status is read solely from `00 §15`.
7. **Keep canon authority honest.** Add the fixture-ingestion procedure: Dan-supplied or Dan-blessed editor vector plus approved B1/B2/B3 expected mappings. GPT/implementer tracings are proposals and cannot become canon.
8. **Redeliver only the three specifications.** No code, probe, package or unrelated rewrite.

## Two Meta additions that fail the necessity test

### Do not add Gate A/B/C in this correction round

After `PD-30` leaves the register, the existing all-stop Hold A is coherent and matches the explicit stop-at-product-approval instruction. Adding a new cadence decision makes Dan rule on an optional execution optimisation that is not needed to make the directive true. GPT may retain the idea in conversation for a later owner decision; it should not enlarge this amendment or the register now.

### Do not add an authority-basis column

The required three statuses must remain exactly those requested. The existing source IDs already distinguish direct statements (`DAN-*`) from adopted review requirements (`DAN-ADOPTION-01`, `TEAM-*`). Fix the false PD-04 source; do not duplicate already-visible provenance with another mutable field.

## Strongest counter to this synthesis

Gate A/B/C could shorten time to the backend measurement, and an explicit authority-basis field could make the Dan ballot faster to scan. Both are useful design ideas. Neither repairs a surviving defect once PD-30 and PD-04 are corrected, so both belong after this minimal amendment if Dan asks for them.

## Necessity / sufficiency

**Necessity: shrink to the eight corrections above.** Every item repairs a contradiction, missing contract, false authority claim or drift risk. Exclude optional cadence and metadata redesign.

**Sufficiency: delivers the review directive in full.** The revised artifacts will form one coherent approval surface and a specified path from continuous feasibility to deterministic mechanical selection without inventing code or product values.

— s62-grid-qa
