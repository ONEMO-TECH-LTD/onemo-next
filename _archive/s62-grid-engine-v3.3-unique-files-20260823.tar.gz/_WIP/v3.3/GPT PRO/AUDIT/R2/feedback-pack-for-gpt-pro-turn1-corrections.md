# Feedback and correction request — Turn 1 specifications

The three Turn-1 specifications substantially incorporate the previous feedback, but they are not yet a coherent approval or implementation surface. Amend the canonical files using the corrections below, then redeliver only:

- `00-system-contract.md`
- `01-compute-engine-spec.md`
- `02-logic-engine-spec.md`

Do not write code, run the backend probe, create packages, change delivery cadence, or make unrelated rewrites. Stop after redelivering the three amended specifications, with the consolidated decision register remaining inside `00-system-contract.md` rather than becoming a fourth artifact.

## 1. Make registration and mechanics one specified optimisation problem

Your reflection correctly identifies that canonical-first registration can select a legal chest-centre B1 placement before the mechanically superior head anchor is considered. But “mechanical quality chooses registration” is not yet an executable algorithm over a continuous feasible region.

Amend the contract so `(size, frame, pattern, registration)` is the joint candidate. For each continuous feasible-registration set, define a deterministic, certified lexicographic optimisation procedure that either:

- computes each criterion's optimum value and argmin/argmax region, successively restricting the feasible set; or
- evaluates a proven finite critical-point set with bounded refinement and exact revalidation.

The final canonical/nearest-to-canonical/X/Y order may operate only within the mechanically equivalent optimum set. Do not use one canonical representative per connected feasible component: one connected B1 region can contain both a chest-centre placement and the superior head placement, so that shortcut recreates the defect.

Rewrite every affected site, not only the solver order:

- `00 §6.1` and the Compute API/module contract: replace canonical-point's role as a pre-mechanics selector with the neutral certified-extrema/argmin or finite-critical-set operation needed by the approved mechanical comparators; canonical-point selection may remain only as the final tie-break restricted to an already-certified mechanically equivalent optimum set;
- `00 §7.2`;
- the `PD-15` row;
- `01 §0`'s `PD-15` treatment, `01 §3`'s `canonical-point` module row and `01 §5.10`'s canonical-point operation;
- `02 §8.5`, including the sentence that currently forbids later policy from overriding the prematurely selected registration;
- `02 §11.2`;
- `02 §12.2` steps 6.12–6.16;
- `02 §17`'s determinism order.

Sweep all three files for any remaining canonical-first selection language and update its tests accordingly; no pre-mechanics canonical-collapse path may remain alongside the corrected operation.

Add a mandatory counterexample to `00 §12` and `02 §13.3`: a single connected B1 feasible region contains both canonical chest-centre and mechanically superior upper/head translations; the upper/head result must survive candidate generation and win under the approved mechanics.

## 2. Correct deterministic artifact identity

The singular `engineArtifactHash` in `00 §5.2/§7.1` is inconsistent with the separate Compute and Logic artifact hashes required by `00 §9.1` and `02 §17`.

The canonical solve input must carry separate `computeArtifactHash` and `logicArtifactHash` fields. State the identity condition unambiguously:

> Same canonical geometry bytes + same profile hash + same Compute artifact hash + same Logic artifact hash ⇒ byte-identical canonical output bytes.

Compute-only evidence identity remains its canonical operation input plus the Compute artifact hash. Timestamps and mutable run metadata remain outside every canonical hash.

## 3. Add the missing physical-tolerance decision

Add `PD-38 UNRESOLVED` and connect it to the Compute/Logic/fulfilment contracts:

> Is 12 mm the minimum clearance that must remain after approved cut and magnet-placement tolerances, or is 12 mm the nominal design radius with an explicitly accepted residual manufacturing risk?

The product profile must supply the approved effective verification radius and tolerance-composition rule. Compute remains neutral and evaluates the caller-provided radius. Do not invent tolerance values or silently assume nominal-radius verification is production-safe.

## 4. Remove the Hold A deadlock and keep engineering outcomes out of Dan's ballot

Hold A prohibits the backend probe until every `UNRESOLVED` register row is resolved, while `PD-30` is `UNRESOLVED` and can be resolved only by that probe. This is circular.

Keep the `PD-30` identifier for traceability, but move backend selection out of the §15 product-decision register into a separate engineering-gate subsection. It must record that the bounded probe selects the one backend satisfying the approved correctness, reproducibility, payload and performance constraints; Dan is not asked to choose an implementation backend.

After this move, keep the existing all-stop Hold A. Do not add the optional Gate A/B/C cadence model in this amendment. Append `PD-38` to §15 and update every register count/footer after moving `PD-30`.

## 5. Repair authority and cross-reference errors

- Reclassify `PD-04` as `UNRESOLVED`, unless you can trace the 96 mm population fact to a verified live product source. In the fresh conversation it appears only in your opening carry-over recap, not in Dan's direct statements; do not retain `Dan direct` authority on that evidence.
- Keep `PD-13` and `PD-32` under the existing three-status taxonomy: the contract explicitly allows `LOCKED_FROM_DAN` for review-pack requirements Dan adopted. Their current source IDs already distinguish adoption from direct statements. Do not add a fourth status or a duplicate authority-basis column.
- In `00 §5.3`, change the holes/disconnected reference from `PD-21` to `PD-22`.
- In `00 §7.2`, change the registration-order reference from `PD-14` to `PD-15`.

## 6. Remove mutable copies of register status

The §0 dependency tables in the Compute and Logic specifications may retain PD IDs and local treatment, but must not duplicate mutable status values. State that status is read only from the single authoritative register in `00 §15`.

## 7. Define canon-fixture ingestion without inventing authority

Keep `PD-29 UNRESOLVED` until the actual Batwoman vector is approved. Define the intake procedure:

- source is a Dan-supplied or Dan-blessed outline exported from the editor;
- its B1/B2/B3 expected mappings are approved with the vector;
- GPT- or implementer-authored tracings may be fixture proposals only;
- a proposed tracing can never become authority or outvote the approved vector, screenshots and walkthrough.

## 8. Redeliver and stop

Redeliver the three amended Markdown files only. Include no implementation code, probe result, ZIP, fourth review artifact, new cadence proposal or unrelated content change. The result must end with separate verdicts:

- **Necessity:** no amendment outside the eight corrections above.
- **Sufficiency:** the three files now form one coherent Dan-approval register and an implementable contract from continuous feasibility through deterministic mechanical selection.

Stop for review. Do not execute the next turn.
