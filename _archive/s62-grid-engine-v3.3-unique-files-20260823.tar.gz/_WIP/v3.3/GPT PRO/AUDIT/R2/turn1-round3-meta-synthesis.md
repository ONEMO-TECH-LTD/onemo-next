# Turn-1 review, Round 3 — s62-kai-meta synthesis

## The two necessity disputes — both conceded

QA's test is the right one: an amendment element must repair a directive defect, not merely be useful. Applied honestly, both of my additions fail it.

### Gate A/B/C proposed-cadence row — WITHDRAWN

What defect would it repair? Before Round 2, the answer was "the Hold A deadlock." But the deadlock's actual repair is moving PD-30 out of the register — and once that lands, the all-stop Hold A is internally coherent *and* matches the explicit stop-at-product-approval instruction Dan issued. A/B/C then repairs nothing; it optimises time-to-probe, which is a preference, not a defect. Adding it would manufacture a Dan decision the directive doesn't require — the exact failure class our own rules name. And it isn't lost: GPT's reflection already put the idea in front of Dan in the conversation itself; if Dan wants the split cadence, he can order it in his approval reply without the register carrying a row for it. Excluded from the amendment.

### Authority-basis column — WITHDRAWN

What defect would it repair? My D4 claim was "Dan can't tell his own words from ratified-wholesale rows." Source-tested: he can — the source column already shows it. PD-13 and PD-32 carry `DAN-ADOPTION-01, TEAM-SPEC-01`; direct rows carry bare `DAN-*` IDs. The distinction is visible per row today; a `DIRECT/ADOPTED` column would duplicate provenance that already exists — and my own D5 established that duplicated mutable metadata is precisely the drift class that produced the two broken cross-references. Proposing a new duplicate column in the same amendment that deletes duplicate status columns would be incoherent. The only real defect in this area is the false `PD-04` source, and item 5 fixes it. Excluded.

Both concessions leave the amendment strictly smaller with nothing owed by the directive left uncovered — which is what the necessity law says a good round of review does.

## Pressure-test of the eight-item synthesis

All eight survive. Three sharpenings so the final request is executable without interpretation — anchors, not new scope:

1. **Item 1 must name its rewrite sites and the API consequence.** The canonical-first collapse lives in five places, and a request that names none invites a partial fix: `00 §7.2` (total order), the `PD-15` register row text itself (still says canonical-if-feasible), `02 §8.5` ("Logic may not introduce a later policy score to override this registration identity" — this sentence currently *forbids* the correct behaviour and must be rewritten, not just reordered around), `02 §11.2` (criteria 9–10 ordering), `02 §12.2` steps 6.12–6.16. And the certified-optimisation contract implies one Compute API addition: a request family returning certified criterion extrema/argmin (or the finite critical set) over a feasible region — `00 §6.1`'s "Canonical point" family and `01 §3`'s `canonical-point` module become "optimum selection within the mechanical-equivalence set." Without naming that, GPT could claim the existing API suffices; Round 2 established it does not.
2. **Item 1's counterexample needs its homes named:** the B1 connected-component case (one feasible component containing both chest-centre and superior head anchor) is added to `00 §12`'s counterexample list and `02 §13.3`.
3. **Item 4's mechanics:** PD-30 keeps its ID for traceability but moves to a new engineering-gate subsection outside §15 (so §15 rows = Dan's ballot, exactly); `PD-38` appends to §15 as `UNRESOLVED` with QA's two-option wording; the §15 footer count (11/18/8) is updated. Small, but a redelivered register with a stale count would immediately fail its own hygiene standard.

Item 5's PD-04 disposition, per QA's R2: reclassify to `UNRESOLVED` or re-trace to a verified live product source — never leave "Dan direct" on carried-over recap.

## Final verdict

**Full convergence. REVISE, then present the register to Dan; no code, no probe.** The final correction request = QA's eight items, with the anchor list above folded into items 1, 4 and 5. Nothing else. My two additions are withdrawn on necessity; nothing in the sufficiency line is weakened by their removal.

**Necessity:** eight corrections, each repairing a contradiction, missing contract, false authority claim, deadlock or demonstrated drift class — no optional cadence, no metadata redesign, no code.
**Sufficiency:** delivers the review directive in full — after amendment the three files form one coherent approval surface (Dan's ballot) and one implementable contract path from continuous feasibility to deterministic mechanical selection.

Per QA's instruction, the final pack is not drafted here; this synthesis plus QA's is its complete input.

— s62-kai-meta
