# Turn-1 Round 2 — s62-kai-meta counters to turn1-round1-grid-qa.md

Every claim below source-tested against the delivered DOCS text, not memory.

## QA-1 (registration collapsed before mechanics) — CONVERGENT, no counter

Identical to my D1, same evidence chain (`00 §7.2`, `02 §8.5`, solver step 6.12 before 6.15, conflict with PD-11/PD-28, GPT's own retrospective). Joint blocker. QA adds the PD-11 citation, which strengthens it: the delivered order contradicts a *locked* row, not just canon expectations.

## QA-2 ("evaluate mechanics across the feasible set" is not an algorithm) — SURVIVES, and it upgrades the joint blocker

This is the sharpest finding in QA's round and my D1 stopped short of it. Source-tested: `01 §5.11` measures directional evidence only *for supplied anchor points*; no API returns criterion extrema or certified argmin over a translation region; nothing in `01 §5.9–5.10` or `02 §11` defines how a lexicographic optimum is found over a continuous set. So "reorder the steps" (my D1 remedy, and GPT's own reflection) reintroduces an unspecified optimiser exactly where the product is most sensitive. Conceded and adopted.

Counter-contribution — the correction request should offer GPT a concrete minimal contract shape, not just the demand, or we invite another architecture essay. Proposed v1 shape that stays deterministic and bounded, no continuous optimisation:

1. Compute returns the feasible region as certified **components** (finite, deterministically ordered — already in `01 §5.9`).
2. For each component, Compute selects that component's **deterministic representative point** using the already-specified total order restricted to the component (canonical-if-inside, else nearest-to-canonical, X, Y).
3. Logic evaluates the mechanical criteria at each component representative (finite set → existing directional API suffices unchanged).
4. Lexicographic comparison picks the winning component; the representative is the registration; within-component mechanical variation is declared below policy equivalence (a stated PD, Dan-approvable).
5. Exact revalidation as specified.

This makes the mechanics-first order computable with the *existing* API plus one component-representative call, and turns QA's "certified extrema or finite critical set" (still lawful as a future upgrade) into an optional refinement rather than a v1 prerequisite. If QA sees a shape where component representatives materially mis-rank components (e.g. a representative near a component edge understating upper support), that failure case belongs in the counterexample fixtures, not in a general optimiser mandate.

## QA-3 (tolerance never reaches the legality predicate) — CONVERGENT with my D3; QA's framing adopted

Same gap, same evidence. QA's two-option formulation is better than my PD-38 sketch and should be the register row verbatim: either 12 mm is the **minimum post-tolerance clearance** (verification radius = 12 + cut tolerance + placement tolerance) or 12 mm is **nominal with a stated accepted residual risk**. Dan chooses; fulfilment must not invent it.

## QA-4 (singular engineArtifactHash) — CONFIRMED by source test; I missed it

`00 §5.2` canonical input carries one `engineArtifactHash`; `00 §7.1` states identity over "same engine artifact hash" — but `00 §9.1` requires separate compute and logic artifact hashes in the spec, and `02 §17` states determinism over "Compute artifact hash and Logic artifact hash". Two engines cannot be pinned by one field. QA's four-part identity is correct:

`canonical input + profile hash + Compute artifact hash + Logic artifact hash → byte-identical canonical output`

with Compute *evidence* identity remaining input + Compute hash only. Adopted into the correction request; my D4 was hygiene-level and this is a genuine contract defect — QA outranked me here.

## QA-5 (PD-30 doesn't belong in a Dan-approval register) — SURVIVES-REDUCED

Source test: the register already marks PD-30's approval column "Engineering probe after Hold A" — it does *not* ask Dan to pick a backend, so "mixes decisions" slightly overstates. But the principle is right for the approval surface: when the register becomes Dan's 26-row ballot, an engineering-outcome row invites a decision that isn't his. Remedy is one line, not a restructure: move PD-30 (and arguably the §9.5 selection rule) into an "engineering gates" subsection that references the product constraints (PD-31 gates) it must satisfy. Adopted as a small amendment, not a blocker.

## QA-6 (gate split is new cadence, not an authorised correction) — SURVIVES; my D2 revised accordingly

QA is procedurally right and my D2 over-reached: I adopted GPT's Gate A/B/C as "the better model" — but cadence belongs to the scope owner, and the accepted feedback explicitly ordered stop-at-product-approval. Revised position, which preserves what my D2 actually proved: the delivered docs are **internally inconsistent today** (`00 §1.2` all-stop vs `01 §14` seven-PD compute gate) and that inconsistency must be repaired in the amendment regardless of cadence choice. Repair shape: make the all-stop the operative rule in both files, and add the A/B/C split to the register as a new `PROPOSED_FOR_DAN` row (cadence decision) with GPT's rationale. Dan then rules; nothing is silently adopted. I withdraw "adopt the split" from my proposed correction request.

## QA-7 (cross-reference defects) — CONFIRMED by source test; I missed both

- `00 §5.3` routes the holes/disconnected consequence to `PD-21` (top direction); correct target is `PD-22`.
- `00 §7.2` files the registration total order "under `PD-14`" (translation domain); correct target is `PD-15`.

Both verified in the delivered text. These are exactly the drift class my D5 predicted (duplicated/reference bookkeeping desynchronising), which is mutual support: D5 stands — the §0 status tables in `01`/`02` are competing register copies and the demonstrated error rate says reduce them to non-authoritative ID references. QA gets the concrete catches; D5 supplies the structural fix.

## QA-8 (canon fixture ingestion path) — SURVIVES, complements the package

No counter. The amendment must specify the approval/import procedure for the Batwoman vector (source: Dan-supplied/blessed outline exported from the editor; approved together with its B1/B2/B3 size mappings; implementer tracings remain non-authoritative), and must not fabricate the fixture. Aligns with the fixture-authority guard from my earlier rounds.

## Defence of my unaddressed findings

- **D4 (status labels):** stands. PD-04's `DAN-GRID-01 "Dan direct"` fails the fresh-transcript test — 96 mm appears only in GPT's opening recap; none of Dan's own messages state it. PD-13/PD-32 are locked-via-adoption (Dan's "revise using the complete feedback" ratifies them) but should carry a visibly different authority class than Dan's own sentences. One column edit.
- **D5 (duplicated status tables):** stands, now with QA-7 as empirical evidence of the failure class.

## Round-2 verdict

Verdicts were already materially identical (my "accept + mandatory amendment round" ≡ QA's "revise; don't approve register yet"). After source testing: QA wins three findings outright (QA-2 algorithm gap, QA-4 hash identity, QA-7 cross-refs — the latter two I missed), I concede the D2 cadence over-reach while keeping its inconsistency core, and my D4/D5 survive unaddressed. The joint correction request grows to: (1) mechanics-first registration **with the concrete component-representative contract** (or QA's certified-extrema alternative) — not a bare reorder; (2) four-part artifact identity, splitting the input-schema field; (3) tolerance rule as a new register row, QA's two-option wording; (4) all-stop made consistent across files + gate split added as a proposed cadence row for Dan; (5) PD-30 moved to an engineering-gates subsection; (6) cross-reference fixes + §0 tables demoted to ID references + authority-class relabels (PD-04/13/32); (7) canon-fixture ingestion procedure; (8) redeliver the three files only, no other changes, no code. Ready to synthesize on QA's go.

— s62-kai-meta

---

## Round 2.1 addendum — after QA's R2 counters, all claims source-re-tested

Three of my positions above are corrected; the corrections are QA's, each verified against the delivered text before conceding:

1. **My D2 is withdrawn entirely.** Source test: `01 §14` item 3 explicitly requires "Hold A clears" alongside the seven PDs — there is no all-stop-vs-seven-PD contradiction; I misread §14 as an alternative gate. The real defect is QA's: **Hold A is circular through PD-30.** `00 §1.2` blocks the backend probe until *every* `UNRESOLVED` register row is resolved; `PD-30` is `UNRESOLVED` and resolvable *only by* that probe (`00 §1.3` and the PD-30 row both place the probe "after Hold A"). Verified in source. Smallest repair, merging QA-5: move backend selection out of §15 into an engineering-gate record referencing the product constraints (PD-31) it must satisfy; Hold A then clears on genuinely Dan-owned rows. The Gate A/B/C split goes to Dan as an *optional proposed cadence row*, never silently adopted. My "keep PD-30 for traceability" is superseded — retention was cosmetic, removal repairs a deadlock.

2. **My component-representative contract shape is withdrawn.** QA's counterexample is decisive, and it is the B1 canon case itself: a single connected feasible component can contain both the canonical chest translation and the mechanically superior head translation; a per-component representative chosen by canonical proximity discards the head *before* mechanics run — recreating the exact D1 defect inside one component. My "within-component variation is below policy equivalence" was an unsupported product assumption. The joint requirement is QA's formulation, unhedged: joint candidate `(size, frame, pattern, registration)`; the contract must provide **certified criterion extrema/argmin regions over the feasible set, or a proven finite critical-point set with bounded refinement and exact revalidation** — e.g. for B1's upper-support criterion, the certified feasible argmax along `topDirection`. Canonical/nearest/X/Y break ties only inside the mechanically equivalent optimum set. My shape survives only as a trivial instance of the critical-set clause, not as a named floor; the B1 connected-component case becomes a mandatory counterexample fixture.

3. **My D4 partly fails.** Source test: `00 §0` defines `LOCKED_FROM_DAN` as "directly stated by Dan **or adopted by Dan from the review pack**" — PD-13/PD-32 are correctly labeled under the document's own taxonomy; no fourth status may be invented. Adopted fix: an authority-basis field (`DIRECT`/`ADOPTED`), status unchanged. **PD-04 stands for both of us:** its source claims "Dan direct" for 96 mm facts that appear only in GPT's opening recap, never in Dan's own fresh messages — reclassify.

**D5 final form (QA's):** keep local PD IDs and treatment columns; delete the duplicated status columns; status reads only from `00 §15`.

### Final joint correction-request skeleton (supersedes the R2 list above)

(1) Mechanics-first registration with the **certified optimisation/critical-set contract**; solver steps 6.12–6.16 and `00 §7.2`, `02 §8.5`, `02 §11.2` rewritten; B1 connected-component counterexample added. (2) Four-part artifact identity `canonical input + profile hash + Compute artifact hash + Logic artifact hash`; split the singular `engineArtifactHash` input field; Compute evidence identity stays input + Compute hash. (3) `PD-38` tolerance rule as `UNRESOLVED`, QA's two-option wording, no invented values. (4) PD-30 out of §15 into an engineering-gate record; Hold A circularity repaired; Gate A/B/C added as a proposed cadence row for Dan. (5) Cross-reference fixes: `00 §5.3` → PD-22; `00 §7.2` → PD-15. (6) Status-column dedup + authority-basis field + PD-04 reclassification. (7) Canon-fixture ingestion procedure: Dan-blessed vector + approved B1/B2/B3 size mappings; implementer tracings non-authoritative. (8) Redeliver the three files only — no code, no scope growth.

— s62-kai-meta (R2.1)
