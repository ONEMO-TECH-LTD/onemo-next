# Turn 1 Round 1 — s62-grid-qa independent position

Scope: `ChatGPT-Grid and Band Logic-20260815-1210.md` and the complete `DOCS/` artifact set only.

## Verdict

**REVISE the specifications; do not approve the decision register yet.** Turn 1 delivered the requested three files and correctly stopped before implementation. The architecture, backend-neutral Compute contract, approximation discipline, capacity-based frames, immutable profiles, and two-stage manufacturing handoff survive. One algorithmic contradiction is load-bearing, and the correction itself exposes a missing mathematical contract.

## Findings

### 1. Registration is collapsed before mechanics — BLOCKER

The system contract §7.2 and `PD-15` choose canonical registration whenever feasible. Logic §8.5 forbids later policy from overriding it. Solver §12.2 step 12 selects that point before requesting directional metrics and constructing the mechanical criteria.

This contradicts both:

- `PD-11`: B1 bbox-centre alignment is only a starting registration;
- `PD-28`: Batwoman B1 must select the upper/head anchor.

If bbox centre is legal but mechanically inferior, the current solver deterministically returns the wrong answer. GPT Pro independently identifies the same defect in its post-delivery retrospective.

### 2. “Evaluate mechanics across the feasible set” is not yet an algorithm

Moving canonical selection later is necessary but insufficient. Mechanical criteria vary continuously with registration. The current Compute API measures directional evidence for supplied anchor points; it does not return certified extrema or a complete finite candidate set over a feasible translation region.

The revised specs must define a joint candidate as `(size, frame, pattern, registration)` and specify how the lexicographic mechanical optimum is found over the continuous feasible set without coarse sampling. Acceptable contract shapes include certified criterion extrema/argmin regions, or a proven finite critical-point set plus refinement. Canonical/nearest/X/Y then acts only inside the mechanically equivalent optimum set.

Without this, the correction reintroduces an unspecified optimiser at the most product-sensitive boundary.

### 3. Production tolerance does not reach the legality predicate — BLOCKER FOR MANUFACTURE

The fulfilment spec records magnet diameter/thickness/tolerances, but no decision defines whether cut tolerance and placement tolerance enlarge the nominal 12 mm protected radius during final verification. GPT Pro notices this only after delivering the files.

Add an explicit product decision: either 12 mm is the minimum post-tolerance clearance, requiring an effective verification radius derived from manufacturing tolerances, or 12 mm is a nominal design value and the accepted residual risk is stated. Do not let fulfilment invent the rule.

### 4. Deterministic identity is inconsistent across the shared contract

System §5.2 and §7.1 refer to one `engineArtifactHash`, while the Engine ManufacturingSpec and Logic determinism contract correctly depend on separate Compute and Logic artifact hashes. Canonical identity must use:

`canonical input geometry + profile hash + Compute artifact hash + Logic artifact hash -> byte-identical canonical output`

The Compute evidence identity remains geometry input + Compute artifact hash only.

### 5. The approval register mixes product decisions with engineering outcomes

`PD-30` is the backend probe result, not a Dan-owned product decision. Keep the consolidated product register, but move evidence-selected technical outcomes into a separate engineering-gate section referencing the product constraints they must satisfy. Dan approves the product/performance boundary; the recorded probe selects the backend.

### 6. Do not silently replace the explicit all-stop cadence

GPT Pro's retrospective proposes three narrower gates and says Compute work could begin before every Logic/Production decision resolves. That may be a useful future execution dependency map, but it is new scope/cadence. The accepted feedback explicitly required Turn 1 to stop at the product-approval hold. Preserve the all-stop unless Dan changes it; present any split as a proposal, not as a correction already authorised.

### 7. Cross-reference defects

- System §5.3 points the holes/disconnected rejection consequence to `PD-21`; it is `PD-22`.
- System §7.2 says the registration total order is under `PD-14`; it is `PD-15`.

These matter because the register is the approval interface.

### 8. Exact canon input remains a real dependency

`PD-29` correctly refuses to let an implementer-authored Batwoman trace become authority. Until an exact vector and its B1/B2/B3 size mappings are approved, the locked outcomes are requirements but not executable regression tests. The correction response must preserve this as unresolved and specify the approval/import procedure; it must not fabricate the fixture.

## Findings that do not survive as objections

- Backend neutrality is genuine; the probe selects one runtime.
- Approximation false negatives are handled substantially better through conservative inclusion, refinement, indeterminate status, and tolerance-boundary evidence.
- Axis class as capacity rather than compulsory occupancy is the correct correction.
- The three-package boundary and three ZIPs remain justified.
- The module seams are disciplined rather than maximally atomised.
- Batwoman is correctly treated as canon constraint, not a calibration corpus.

## Necessity and sufficiency

**Necessity — shrink:** remove premature canonical-point selection from the system-level pre-mechanics path; remove the backend result from the product-decision register; do not add a new gate programme without Dan's cadence decision.

**Sufficiency — partial:** missing continuous mechanical optimisation contract, tolerance-adjusted production legality rule, consistent four-part artifact identity, correct approval references, and an approved canon-fixture ingestion path.

