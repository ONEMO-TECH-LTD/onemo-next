# R2 follow-up amendment request

Your R2 redelivery implements all eight prior corrections. It is not yet ready to become the Hold A ballot. Make only the five amendments below, redeliver the same three Markdown files, and stop. Do not write code, run a backend probe, add a phase, or expand architecture.

## 1. Make uncertainty propagation dominance-safe

The current text permits an unsound reading:

- `00 §10` allows an indeterminate result to be hidden or flagged;
- `02 §11.1` makes a candidate ineligible when a “required result” is indeterminate without defining which results are required;
- `02 §12.2` step 6.11 permits “reject or carry” without a rule for choosing.

Define the two cases explicitly:

- a candidate with indeterminate **legality** is excluded outright because it cannot be manufactured; a proven-legal rival may still win;
- a proven-legal candidate with an uncertain **criterion score** may be pruned only when it is certified dominated under the current comparator. Otherwise the affected size/band decision returns `DECISION_INDETERMINATE` and produces neither an offer nor a ManufacturingSpec.

UI policy may hide the entire affected score-indeterminate offer; it may not drop a proven-legal, score-uncertain candidate and proceed with a rival winner.

Rewrite `00 §10`, `02 §11.1`, and `02 §12.2` steps 6.11 and 6.15 consistently. Add both mandatory verification cases:

- A is proven legal with certified score 10; B is proven legal with certified score interval [9,11]. Rejecting B and selecting A must fail unless B is certified dominated under the complete comparator.
- A is proven legal with certified score 10; B's legality is indeterminate. Excluding B and selecting A must pass.

## 2. Put the exact mechanical selection policy on the ballot

`01 §5.10.1` currently says descriptor families “MAY include” examples. `02 §11.2` gives qualitative criterion names. `PD-20` asks Dan to approve only the order. This does not ballot the exact policy the engine must implement.

Replace the optional examples with a concrete, versioned v1 descriptor registry. For every `02 §11.2` criterion, specify:

- exact descriptor ID and formula;
- exact comparator, including ordering within compound criteria;
- certification method;
- numeric equivalence tolerance and unit.

Place the complete proposed table on Dan’s approval surface by expanding `PD-17`/`PD-20` or adding one atomic unresolved policy-decision row. The ballot must approve or amend the actual registry, formulas, comparator details, certification choices and tolerances—not merely the prose criterion order. Update all three files and their verification cases consistently.

## 3. Close the conditional 96 mm population-origin phase gap

If `PD-04`/`PD-34` confirms a fixed-origin 96 mm sparse population, specify its discrete population-origin parity explicitly. Use one complete model consistently:

- population origin is a discrete frame-hypothesis dimension while translation remains in one 48 mm master-lattice period; or
- translation spans the active population’s fundamental period.

Do not silently treat the extra population-origin choice as covered by `PD-14`’s current one-48-mm-period domain. Make the dependency visible in the affected decision rows and `02 §6.4`. This remains conditional on `PD-04`.

## 4. Correct the artifact name

In `01 §11.6`, change singular “engine artifact” to “Compute artifact” in the Compute-only determinism test.

## 5. Restore decision traceability and parameterization

In `02`, cite `PD-25`, `PD-26` and `PD-33` wherever their governed content is implemented: coordinate quantum, approximation tolerance, and fulfilment component fields respectively.

In `01 §9.4`, replace the fixed “0.01 mm intrusion case” with “one approved coordinate quantum of intrusion.” Retain 0.01 mm only as the proposed case conditional on `PD-25` being approved unchanged.

## Required response

Redeliver only:

1. `00-system-contract.md`
2. `01-compute-engine-spec.md`
3. `02-logic-engine-spec.md`

Then report, for each of the five items, the exact amended sections and whether the correction is complete. End with separate verdict lines:

- **Necessity:** no unnecessary elements / name what should shrink.
- **Sufficiency:** delivers the five amendments in full / name what remains partial.

Stop after the documents and verdict. The register still goes to Dan only after the redelivery is independently checked.
