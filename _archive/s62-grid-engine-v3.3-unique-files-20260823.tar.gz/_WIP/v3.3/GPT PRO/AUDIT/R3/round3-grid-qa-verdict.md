# R2 redelivery — Grid QA verdict

## Source coverage

Read in full, no skipped ranges:

- `ChatGPT-Grid and Band Logic-20260815-1759.md` — 5,339 lines
- `DOCS/R2/00-system-contract(1).md` — 614 lines
- `DOCS/R2/01-compute-engine-spec(1).md` — 864 lines
- `DOCS/R2/02-logic-engine-spec(1).md` — 1,127 lines

The R2 files implement all eight requested amendments and introduce no code, probe, package or cadence expansion. They are still **not ballot-ready** because two selection-policy defects remain.

## Blockers

### 1. A proven-legal candidate with an indeterminate score can still be discarded without proof that it cannot win

The Compute contract correctly forbids an approximate optimiser from discarding a potentially better registration (`01 §6.5`). The Logic contract then reopens that failure:

- `00 §10` says an indeterminate result may be hidden or flagged;
- `02 §11.1` makes a candidate ineligible when a required result is indeterminate, without defining which result types this covers;
- `02 §12.2` step 6.11 permits “reject or carry” with no dominance rule.

Counterexample: candidate A is proven legal with certified score 10; candidate B is proven legal with certified score interval [9,11]. Rejecting or hiding B and selecting A may return the wrong optimum.

Required invariant: a candidate with indeterminate legality is excluded because it cannot be manufactured, and a proven-legal rival may still win. A proven-legal candidate with an uncertain criterion score may be pruned only when certified dominated under the current comparator. Otherwise the affected size/band decision returns `DECISION_INDETERMINATE` and cannot produce an offer or ManufacturingSpec. UI policy may hide the entire affected score-indeterminate offer; it may not convert score uncertainty into a different winner.

Amend `00 §10`, `02 §11.1`, `02 §12.2` steps 6.11/6.15, and add both verification cases: the proven-legal score interval must block unless dominated; an indeterminate-legality candidate must be excludable without blocking a proven-legal rival.

### 2. Hold A can clear without the mechanical policy being executable

`01 §5.10.1` says the neutral descriptor families **may** include several operations, but does not publish a required v1 descriptor registry. `02 §11.2` names qualitative criteria, while `PD-20` asks Dan to approve only their order. The exact criterion-to-descriptor mapping, formulas, compound-comparator ordering and equivalence tolerances remain absent.

Examples:

- “distribution” does not define its exact distinct-region comparator;
- “geometric/visual balance” does not define whether centroid distance or left/right imbalance compares first, or how they combine;
- `PD-17/PD-20` are said to govern equivalence tolerances, but their ballot rows contain none.

Required correction:

- replace “MAY include” with a concrete, versioned v1 descriptor registry;
- map every `02 §11.2` criterion to an exact descriptor/formula, comparator, certification method and equivalence tolerance;
- put that complete table on Dan’s approval surface by expanding `PD-17/PD-20` or adding one atomic unresolved row.

Profile-schema invariants prevent an incomplete profile from running, but they do not make the missing policy ballot-visible or implementation-ready.

## Conditional contract defect

### 3. A fixed 48 mm phase domain is incomplete if the 96 mm population is confirmed

`PD-14` fixes registration search to one 48 × 48 mm phase period. If `PD-04/PD-34` confirms a fixed-origin 96 mm sparse population, it adds discrete population-origin parity not covered by that single 48 mm phase.

Specify one of these equivalent complete models:

- population origin is an explicit discrete frame-hypothesis dimension and translation remains within one 48 mm master-lattice period; or
- translation spans the active population’s fundamental period.

This correction is conditional on confirming `PD-04`, but it must be visible before Dan can approve `PD-04`, `PD-14` and `PD-34` together.

## One-line hygiene fixes in the same amendment

1. `01 §11.6`: change singular “engine artifact” to “Compute artifact” in the Compute-only determinism test.
2. `02`: add missing `PD-25`, `PD-26` and `PD-33` citations where coordinate quantum, approximation tolerance and fulfilment component fields are implemented.
3. `01 §9.4`: replace the hard-coded “0.01 mm intrusion case” with “one approved coordinate quantum of intrusion”; 0.01 mm remains the case only if `PD-25` is approved unchanged.

## Necessity / sufficiency

**Necessity: shrink to the three contract corrections and three one-line hygiene fixes above.** No code, new cadence, backend choice or architecture expansion is justified.

**Sufficiency: partial.** All previous eight amendments landed, but the register cannot go to Dan until uncertainty propagation is dominance-safe and the exact mechanical comparator policy is present on the ballot. The 96 mm phase dependency must also be closed before `PD-04/PD-34` can be confirmed.

## Verdict

**REVISE once more; do not present the R2 register as Hold A’s ballot yet.** Redeliver the same three Markdown files only and stop. No implementation or backend probe.

— s62-grid-qa
