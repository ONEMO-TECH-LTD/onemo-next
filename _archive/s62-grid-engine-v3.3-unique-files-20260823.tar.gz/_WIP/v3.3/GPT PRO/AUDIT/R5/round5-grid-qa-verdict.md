# Round 5 — s62-grid-qa verdict on the direct global-anchor amendment

## Verdict

**CLEAR — the direct amendment is correct, minimal and ballot-ready.** The three Turn-1 specifications now define an executable two-phase global-anchor restriction, preserve Compute neutrality, distinguish one-sided anchor equivalence from symmetric candidate equivalence, and encode the required adversarial fixtures. Hold A remains active; this verdict authorises the 27-row product ballot, not implementation.

## Evidence surface

Observed the current files directly in `DOCS/R3` and compared them line by line with the untouched genuine-R3 baseline in `AUDIT/R4/baseline-pre-anchor/` through the regenerated 187-line cumulative diff `AUDIT/R4/round4-anchor-amendment.diff`.

Current SHA-256 identities:

- `00-system-contract(2) (1).md`: `755b7be5453dbffb600c5efb41f4b8726bc1d838bd9f46b035aea2316430dc2e`
- `01-compute-engine-spec(2).md`: `7c38d8452dfae17908836e6c28cba3cbff42876a2ddeab1bec67bac5a54fe7cd`
- `02-logic-engine-spec(2).md`: `a845f183033809b4538e234c1f840f31b4ed4127b24d952ed514e07d8981cada`
- cumulative diff: `c35973e5a491c2a695604fbb06a3c5c2613dd4c424845cab3c6f5a73a8a0158b`

The baseline hashes match the genuine R3 hashes recorded before Meta edited. The cumulative diff contains only the global-anchor amendment, the interval-semantics corrections required to make it sound, their regression fixtures, and the necessary R4 provenance/self-verdict updates. No module, criterion, product decision, gate or code was added; register statuses and counts are unchanged.

## Contract trace

1. **Optional restriction anchor — PASS.** `00` §6.1 accepts the certified global optimum scalar/compound interval or threshold as neutral numeric input.
2. **Two-phase operation — PASS.** `00` §§6.3/7.2, `01` §5.10.2 and `02` §§8.5/12.2/17 require local optimum evidence, global-best certification, then an anchored Compute restriction for every surviving hypothesis. Reusing the local subset is expressly forbidden.
3. **Scalar interval semantics — PASS.** Conservative exclusion remains `min: lower(x) > upper(anchor)+tau` and `max: upper(x) < lower(anchor)-tau`; equality remains equivalent.
4. **Compound anchor semantics — PASS.** A later component may decide only when every earlier component is certified equivalent for every possible anchor value: `min: upper(x) <= lower(anchor)+tau`; `max: lower(x) >= upper(anchor)-tau`. Otherwise retain/refine; later-component exclusion is forbidden.
5. **Candidate dominance semantics — PASS.** Candidate-to-candidate earlier-component equivalence is explicitly symmetric and cannot reuse the one-sided anchor rule.
6. **Fixtures — PASS.** Both suites contain the scalar global-anchor case and compound anchor-uncertainty case; `00` and `02` contain the symmetric candidate-dominance case.
7. **Traceability — PASS.** `DAN-ADOPTION-04` and `TEAM-AMEND-04` record direct authorship/adoption; `01`/`02` traceability and `PD-15` cite it; `00` §14 now truthfully describes the current artifact set.

## Adversarial results

All evaluated against the normative inequalities in the current files:

- Scalar `min`, `tau=1`, anchor `0`: B at `0.9` survives; B at `1.9` is excluded.
- Exact boundary: `1.0` survives and `1.01` is excluded; the symmetric `max` boundary behaves identically.
- Non-degenerate anchor `[0,10]`, registration `[11,11]`, `tau=1`: neither certified equivalent nor excludable; it is retained/refined.
- Compound anchor `([0,0],[0,0])`, registration `([0.5,1.5],[100,100])`, `tau=(1,1)`: component 1 remains uncertain, so component 2 cannot exclude it.
- Candidate X `(0,100)` versus Y `(10,0)`, `tau=(1,1)`: component 1 is not symmetrically equivalent and decides for X; X cannot be pruned through component 2.
- Positive symmetric-equivalence and `max` anchor cases also pass.

## Necessity / sufficiency

**Necessity:** no unnecessary elements. Every changed line either implements the cleared global-anchor correction, repairs an adversarially demonstrated interval error in that correction, encodes its regression proof, or keeps the specification's source chain and self-verdict truthful.

**Sufficiency:** delivers in full. The original non-transitivity failure is closed for exact and certified scalar/compound intervals, local subsets cannot substitute for the global restriction, uncertainty cannot leak into a later comparator component, and the current documents contain executable failure/refinement semantics and mandatory tests.

— s62-grid-qa
