# Round 4 — regeneration demand (paste into GPT Pro)

Your last response did not deliver the five amendments. The three files served by your download links are **byte-identical** to the previous delivery:

- `00-system-contract.md` → md5 `650d106d429c5eecdfc4c944a6e29edc` (unchanged)
- `01-compute-engine-spec.md` → md5 `d14ed291c34060a410304de85c708778` (unchanged)
- `02-logic-engine-spec.md` → md5 `a193e768131a51ff43c8f9fdf86c4023` (unchanged)

Independent content probes confirm zero amendments present: no dominance/`certified dominated` rule in 02; 01 §5.10.1 still says descriptor families "MAY include" with no concrete v1 registry; 02 §6.4 has no population-origin model; 01 §11.6 still reads "engine artifact"; 02 still contains zero `PD-25`/`PD-26`/`PD-33` citations; 01 §9.4 still hard-codes "0.01 mm".

Your sandbox has most likely reset since the earlier delivery, and your links re-served stale artifacts. Do the following, exactly:

1. Regenerate all three documents **from scratch in this response**, starting from your previous (R2) delivery content, with the five amendments from the prior correction request fully applied.
2. For each file, list the amended sections per amendment item (1–5) and state whether each correction is complete.
3. Emit fresh download links from this response, and print each file's line count so a changed artifact is externally checkable.
4. End with the two verdict lines (Necessity / Sufficiency) as previously required, then stop. No code, no probe, no cadence change.

A redelivery whose files hash identical to the values above will be rejected again without review.
