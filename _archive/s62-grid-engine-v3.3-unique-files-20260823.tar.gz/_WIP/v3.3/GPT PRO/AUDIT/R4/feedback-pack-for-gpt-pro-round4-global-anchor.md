# Round 4 correction request — global-optimum-anchored restriction

Your genuine R3 redelivery was read in full by independent QA and Meta. All five requested amendments landed. One new selection-critical executability gap remains, so the register is not yet ballot-ready.

## Required amendment

The current optimisation request returns each hypothesis's tolerance-equivalent registration subset relative to that hypothesis's own local optimum. Logic then compares those local optima globally, but no defined Compute operation re-restricts each surviving continuous feasible set against the certified global optimum.

This is incorrect because tolerance equivalence is not transitive. For a minimised scalar criterion with `tau = 1`:

- A has attainable scores `{0}`;
- B has attainable scores `{0.9, 1.9}`;
- B's locally equivalent subset may retain both `0.9` and `1.9`;
- B survives because its optimum `0.9` is equivalent to global best `0`;
- a later criterion may then select B at `1.9`, outside tolerance of global best `0`.

Amend the existing contracts as follows:

1. In `00-system-contract.md` §6.1 and §7.2, extend registration-criterion optimisation with an optional caller-supplied restriction anchor: the certified global optimum scalar or compound interval/threshold. When supplied, Compute returns a conservative subset of the supplied feasible set containing every registration that may remain equivalent to that anchor under the approved tolerance. The anchor is numeric comparator input, not product policy; Compute neutrality remains unchanged.
2. In `01-compute-engine-spec.md` §5.10.2, define exact and interval-certified scalar/compound equivalence against the supplied anchor, including refinement/failure semantics. Keep the existing local-optimum request for phase one; add the anchored restriction mode for phase two.
3. In `02-logic-engine-spec.md` §8.5 steps 3–4 and §12.2 steps 6.13–6.14, state the executable two-phase sequence: obtain each hypothesis's local optimum evidence; certify the global best across hypotheses; then issue an anchored restriction request for every surviving hypothesis before advancing to the next criterion. Logic must not reuse a locally anchored equivalent subset as the final global restriction.
4. In `02` §11.3, define scalar and compound interval equivalence against the certified global anchor consistently with `01`.
5. Add the counterexample above to `01` §11.3 tests and `02` §19.5. Required result: B remains a surviving hypothesis after criterion 1, but B's `1.9` registration is removed before criterion 2. Test both exact scores and certified intervals at the tolerance boundary.

Sweep the three files for any statement that still permits a hypothesis-local tolerance subset to stand in for the global restriction. Do not add a new module, criterion, product decision, gate or code.

## Required response

Return:

1. a short amendment map naming every changed section;
2. both verdicts: **Necessity** (`no unnecessary elements` or name what should shrink) and **Sufficiency** (`delivers in full` or name what remains partial);
3. fresh downloadable copies of all three amended Markdown files;
4. no code and no Turn-2 implementation work.
