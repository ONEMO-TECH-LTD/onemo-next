# Round 4 — s62-grid-qa verdict on the genuine DOCS/R3 delivery

## Verdict

**REVISE — the five requested amendments conform, but the contracts are not ballot-ready.** The joint optimisation flow requires a global-optimum-anchored restriction that the Compute contract cannot currently perform.

## Sources and coverage

Read in full:

- `DOCS/R3/00-system-contract(2) (1).md` — 654 lines — SHA-256 `88c78db37b2891770519de81a19d69e559328d8a271c46859a7cd720f662b65f`
- `DOCS/R3/01-compute-engine-spec(2).md` — 879 lines — SHA-256 `e47463fd4664fa485e1b6165781b2e65440b2665a9e83a048c2c9266ead0c118`
- `DOCS/R3/02-logic-engine-spec(2).md` — 1,147 lines — SHA-256 `ab6ba73c49f136ed499192ee9b764f772f198aa336851c7625aff24454aedc3b`
- `DOCS/ChatGPT-Grid and Band Logic-20260815-2024.md` — 5,483 lines — SHA-256 `d1dfd35da3b699ecc105e724262f303e5b08506822b6a2481bf250bcbe422fe3`
- `AUDIT/R3/feedback-pack-for-gpt-pro-round3.md`

The earlier R2-identical downloads were stale artifacts and do not support this verdict. The hashes above identify the genuine R3 delivery.

## Round-3 amendment trace

1. **Legality versus score uncertainty — PASS.** `00` §7.2.1, `02` §§11.1/11.3/12.2 and the twin fixtures distinguish legality-indeterminate exclusion from dominance-safe handling of proven-legal score uncertainty.
2. **Executable mechanics ballot — PASS.** `01` §5.10.1 defines the closed ten-descriptor `geometry-criteria-v1` registry; `02` §11.2 maps M01–M10 to exact formulas, comparators, certification methods and tolerances.
3. **Conditional 96 mm origin phase — PASS.** `00` PD-04/14/34 and `02` §§6.4/8.4 model population origin parity as a discrete hypothesis rather than an enlarged translation domain.
4. **Compute artifact wording — PASS.** `01` §11.6 is corrected.
5. **Traceability and quantum parameterisation — PASS.** `01` §9.4 uses the approved coordinate quantum; `02` cites PD-25/26/33 at the implementation and verification sites.

The Batwoman canon remains attainable through the policy rather than hard-coding: B1 through M02, B2 through M02/M03, and B3 through M01.

## Blocking finding — local tolerance sets can admit a globally inferior registration

`00` §6.1 defines registration optimisation from a current feasible set, descriptor and tolerance, with no global restriction anchor. `01` §5.10.2 therefore returns a mechanically equivalent subset relative to that input set's own optimum. `02` §8.5 requests those local subsets before determining the best value across hypotheses, then requires a global restriction without defining a Compute operation that can construct it. Logic cannot construct the geometric sublevel set itself because `02` §2 assigns geometry operations to Compute.

Tolerance equivalence is not transitive. Counterexample for a minimised scalar criterion with `tau = 1`:

- hypothesis A has attainable scores `{0}`;
- hypothesis B has attainable scores `{0.9, 1.9}`;
- B's local optimum is `0.9`, so its locally anchored equivalent subset may retain both `0.9` and `1.9`;
- A's optimum `0` and B's optimum `0.9` are equivalent, so B survives the cross-hypothesis comparison;
- a later criterion may select B at `1.9`, although `1.9` is not equivalent to the global best `0`.

The prose in `00` §7.2 step 4, `02` §8.5 step 4, §12.2 step 6.14 and §17 requires global restriction, but the only defined request is local-optimum-anchored. This is an executable-contract gap, not merely an implementation choice.

## Minimal correction

One bounded amendment across the existing seams:

1. Add an optional caller-supplied certified global optimum interval/threshold as a restriction anchor to the registration-criterion optimisation request in `00` §6.1.
2. Define scalar and compound equivalence against that anchor in `01` §5.10.2 and `02` §11.3.
3. Make the two-phase flow explicit in `02` §8.5 steps 3–4 and §12.2 steps 6.13–6.14: compute local optima, certify the global best, then ask Compute to re-restrict every surviving feasible set against the global anchor.
4. Add the counterexample to `01` §11.3 and `02` §19.5. Required outcome: hypothesis B survives criterion 1, but B's `1.9` registration does not.

No new module, policy criterion, gate or implementation work is required.

## Necessity / sufficiency

**Necessity:** no unnecessary elements — retain the R3 delivery and add only the missing anchor parameter, its semantics, the two-phase call sequence and one fixture.

**Sufficiency:** partial — all five Round-3 corrections landed, but the contracts do not yet prevent a later criterion from selecting a registration outside tolerance of the global optimum. The amendment above closes the remaining executable gap.

— s62-grid-qa
