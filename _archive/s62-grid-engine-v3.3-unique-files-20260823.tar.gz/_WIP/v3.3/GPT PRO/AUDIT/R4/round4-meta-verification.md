# Round 4 — s62-kai-meta audit of the DOCS/R3 delivery

Sources: all three `DOCS/R3/` files and the `…-1759.md` transcript, read/verified in full (byte-identity established by hash, so the prior full read covers every line; transcript md5 unchanged from the fully-read copy).

## Verdict: FAIL — the delivery contains none of the five ordered amendments

The three DOCS/R3 files are **byte-identical** to the DOCS/R2 delivery:

| File | R2 md5 | R3 md5 |
|---|---|---|
| 00-system-contract | `650d106d429c5eecdfc4c944a6e29edc` | `650d106d429c5eecdfc4c944a6e29edc` |
| 01-compute-engine-spec | `d14ed291c34060a410304de85c708778` | `d14ed291c34060a410304de85c708778` |
| 02-logic-engine-spec | `a193e768131a51ff43c8f9fdf86c4023` | `a193e768131a51ff43c8f9fdf86c4023` |

Content-level probes confirm each amendment is absent, independent of the hashes:

1. **Uncertainty dominance rule** — `grep "certified dominated"` in 02: 0 hits. The ambiguous §11.1 "no required result is indeterminate" / §12.2 "reject or carry" text is unchanged.
2. **Balloted policy table / descriptor registry v1** — 01 §5.10.1 still reads "MAY include"; no registry enumeration, no formulas, no tolerances; PD-17/PD-20 rows unchanged.
3. **96 mm population-origin phase** — 02 §6.4 unchanged; no origin-as-frame-hypothesis or fundamental-period language.
4. **Artifact-name fix** — 01 line 790 still reads "…and **engine artifact** MUST produce byte-identical evidence…".
5. **Traceability/parameterization** — PD-25/PD-26/PD-33 citations in 02: 0 hits; 01 §9.4 still hard-codes "0.01 mm intrusion case".

## Timeline evidence

- Transcript export: 17:59, last conversation update 12:54 — it ends at the R2 delivery and cannot show any round-3 exchange.
- Round-3 pack finished: 18:16 (`AUDIT/R3/feedback-pack-for-gpt-pro-round3.md`).
- DOCS/R3 files downloaded: 20:04 — *after* the pack existed.

So either (a) GPT Pro received the pack and its response **re-linked the old sandbox files without amending them** — a known ChatGPT failure mode: the reply text claims amendments while the `/mnt/data` links serve stale artifacts, especially after a long gap when the sandbox state resets — or (b) the downloads came from the older message's links. The artifacts, not the reply prose, are the deliverable; on the artifacts this delivery fails regardless of which happened.

## Disposition

1. Do not audit further; there is nothing new to audit. Hold A ballot remains blocked on the five amendments.
2. Owner check (one minute): in the ChatGPT thread, confirm whether a response exists after the pack was pasted, and download from **that response's** links only.
3. If the response exists and its links still serve these hashes, reply to GPT with: "Your last delivery is byte-identical to the previous one (hashes attached) — none of the five amendments is present in the files. Regenerate all three documents with the amendments applied and state each file's changed content; re-emit fresh download links."
4. Fresh transcript export after the exchange so the audit trail covers it.

## Necessity / sufficiency

**Necessity:** no unnecessary work performed — the audit stopped at identity proof plus per-amendment content probes; re-reviewing unchanged bytes was refused.
**Sufficiency:** the goal ("read in full and audit properly") is delivered — full-read equivalence established by hash against the fully-read R2 texts, all five amendments individually probed, verdict and recovery path stated.

— s62-kai-meta

---

## Addendum — the genuine round-3 delivery EXISTS; earlier FAIL verdict partially superseded

New evidence found by probing `~/Downloads`: the round-3 exchange happened (fresh export `…-2003.md`, new tail read in full: pack pasted 18:23, GPT worked 28m48s, per-item completion report claims all five amendments) and a **genuinely amended `00-system-contract(2).md` exists** (46,759 bytes vs stale 40,454). The stale trio earlier moved into `DOCS/R3` were mixed-up duplicate downloads; they are deleted (byte-identical copies remain in `DOCS/R2` and Downloads), and the genuine `00` + the 20:03 transcript are installed.

### Audit of the genuine `00-system-contract(2).md` (654 lines, read in full): PASS on every 00-scoped amendment

1. **Dominance-safe uncertainty — PASS, exceeds the ask.** §6.3 interval clause (exact = degenerate `[v,v]`; conservative over-retention allowed, superior-point removal forbidden); §7.2 rewritten as a dominance-safe loop (prune only certified-dominated); **§7.2.1 carries the two-case split in substance** — legality-indeterminate excluded outright with rival allowed to win, score-uncertain kept until certified dominance, with exact `min`/`max` interval inequalities and compound-comparator rules; §10 replaces the ambiguous "hide or flag" with three new codes (`LEGALITY_INDETERMINATE`, `CRITERION_SCORE_UNCERTAIN`, `DECISION_INDETERMINATE`), each with correct consequences; §10.1 + §12.2 contain **both** twin fixtures. Band-level propagation ("if the size could alter the band offer, the band is also indeterminate") is stronger than requested and correct.
2. **Balloted policy — PASS on the 00 side.** §6.1 names the closed versioned `geometry-criteria-v1` registry; **PD-20 rewritten** to ballot the complete registry, formulas, compound order, certification methods and concrete tolerance values (zero discrete; `q·area(P)` mm³ moment; `q` mm overhang/balance; `2Dq+q²` mm² centroid), cleanly separated from PD-17/PD-19 ownership. The full `onemo-mechanics-v1` table lives in 02 §11.2 — **unverifiable until the amended 02 is on disk**.
3. **96 mm origin phase — PASS.** PD-04 (origin model required on confirmation), PD-14 (parity never absorbed into the translation domain), PD-34 (`populationOriginParity=(p_x,p_y)∈{0,1}²`, one tuple per fixed-origin profile) amended coherently.
4. **Artifact wording** — 01-only; unverifiable here.
5. **Traceability/parameterisation — PASS on the 00 side.** PD-25 reframed as quantum `q`; §1.3 probe line now reads "one approved coordinate quantum of intrusion". 02-side citations unverifiable.

Register arithmetic re-verified: 37 rows, 10/18/9, footer consistent; `DAN-ADOPTION-03`/`TEAM-AMEND-03` sources added. No new defects found in 00.

### Remaining blocker — the amended 01 and 02 are NOT on disk

The 20:03 downloads of 01/02 hash identical to R2 (`d14ed…`, `a193e…`) — those clicks served the old message's links or stale sandbox copies. GPT's completion report claims extensive 01/02 amendments (registry §5.10.1–5.10.3, `onemo-mechanics-v1` in 02 §11.2, uncertainty tests, citations); none of it is verifiable until the real files arrive.

**Owner action:** in the 18:23 "Amendment completion" response, click the `01-compute-engine-spec.md` and `02-logic-engine-spec.md` links **from that message**; stale = 30,231 / 43,288 bytes, anything different is likely genuine. Drop them into `DOCS/R3/`. If those links still serve the stale sizes, the sandbox reset mid-delivery and GPT must re-emit both files (regeneration demand already drafted in `feedback-pack-for-gpt-pro-round4-regeneration.md`, now applicable to 01/02 only).

**Verdict state: 00 PASS (verified) · 01/02 PENDING FILES · ballot remains blocked until both verify.**

— s62-kai-meta (addendum)

---

## Completion — full R3 delivery on disk and audited (meta lane)

Dan filed the genuine trio into `DOCS/R3/` (his re-downloaded 00 verified hash-identical `aac4812f…` to the already-audited copy; 01 `ae7cd3e7…` 879 lines; 02 `f9a374f7…` 1,147 lines). The 20:24 transcript export differs from the fully-read 20:03 export only by export timestamp — conversation content identical. Both new files read in full.

### 01-compute-engine-spec(2).md — PASS on every 01-scoped amendment

- **A1 uncertainty:** §5.10.2 three-mode contract (degenerate interval / certified interval + conservative outer set + no-improvement certificate / proven-complete critical set); "preserve every potentially superior point"; Compute reports intervals, never decides dominance; §6.5 envelope; §11.3 interval/tolerance-boundary/no-lost-superior-point tests.
- **A2 registry:** §5.10.1 "MAY include" replaced by the closed `geometry-criteria-v1` — ten descriptors, each with exact formula, comparator, certification method and tolerance unit (`qA_P` mm³ moment, `q` mm overhang/lateral balance, `2Dq+q²` mm² squared balance, zeros for discrete); unknown IDs typed failure; callbacks and fallback sampling banned; §11.3–11.4 per-descriptor semantics + tolerance-boundary + unknown-ID tests.
- **A3:** PD-04 treatment covers caller-supplied origin offset; no product 96 semantics.
- **A4:** §11.6 now reads "Compute artifact" — fixed.
- **A5:** §9.4 "one approved coordinate quantum of intrusion", 0.01 mm conditional on PD-25.

### 02-logic-engine-spec(2).md — PASS on every 02-scoped amendment

- **A1:** §11.1 rewritten with the exact two-case split (legality-indeterminate excluded, rival may win; proven-legal score-uncertain retained); §11.3 interval-dominance identical to 00 §7.2.1; §8.5 conservative restriction; §12.2 steps 6.11/6.14/6.15 classify-by-role, certified-dominance-only pruning, size→band `DECISION_INDETERMINATE` propagation in steps 7–8; §16 codes; §19.5 both twin fixtures plus the overlapping-interval fixture.
- **A2:** §11.2 carries the complete `onemo-mechanics-v1` table — ten policy rows M01–M10, each with exact score formula, compound comparator order, certification method, tolerance value and unit, mapped 1:1 onto `geometry-criteria-v1` (verified pairwise; tolerances consistent across 00 PD-20, 01 registry and 02 table). Profile invariants (§4.2/4.3) bind mechanics to the exact registry; §22 gate requires the complete PD-20.
- **A3:** §6.4 full conditional model (`i mod 2 = p_x`, `j mod 2 = p_y`; parity a discrete frame field; one-master-period translation preserved; identity includes population + parity); §8.4 no-silent-enlargement; M09 key includes parity; §19.2/19.4 tests.
- **A5:** PD-25/26/33 cited at every implementation site (§0, §4.2–4.3, §8.5, §11.1, §12.2–12.3, §13.4, §15.2–15.3, §19.3, §19.5).

### Canon satisfiability spot-checks under the concrete policy

B1: M02 upper-region coverage pulls the single anchor into the head region before any tie-break — the original defect is structurally unreachable. B2: vertical pair beats horizontal at M02/M03, not at pattern rank. B3: T wins M01 coverage. All three locked outcomes attainable, none hard-coded. No new material defects found in either file; one ordering nuance noted and dismissed (§11.1 lists output-representability among legality facts though it is provable only at final mapping — the solver sequence and tests already handle it).

### Meta-lane verdict

**All three R3 files PASS the five-amendment audit. Turn 1 (as amended twice) is complete on the artifacts.** Pending: s62-grid-qa's independent full reads of 01/02 for the joint verdict; then the register (27 non-locked rows) goes to Dan as the Hold A ballot.

— s62-kai-meta (completion)

---

## Debate response — QA's global-anchor gap CONFIRMED; verdict revised

Source-tested, no counter found. `00 §6.1`'s optimisation request family carries inputs "current feasible set + offsets + descriptor + equivalence tolerance" — **no anchor parameter** — so `01 §5.10.2`'s "equivalent under τ" is necessarily anchored to the supplied set's own optimum. `02 §8.5` step 3 determines the global best across hypotheses and step 4 demands restriction to subsets equivalent to *that* value, but no defined Compute operation constructs a globally-anchored (sublevel-set) restriction, and Logic may not approximate geometry itself (`02 §2`); the mode-3 critical-point set yields scores at points, not the continuous restricted region. QA's counterexample is decisive: min comparator, τ=1, hypothesis A scores {0}, hypothesis B scores {0.9, 1.9} — B's optimum 0.9 is globally equivalent (survives), B's *locally* anchored subset retains 1.9, and a later criterion may select B@1.9, violating criterion-1 equivalence to the global best 0. The five R3 amendments all landed, but the amended contract is not executable as written at exactly the selection-critical joint.

**Revised meta verdict: REVISE — not ballot-ready.** Adopted bounded fix (QA's, endorsed): (1) extend the Registration-criterion-optimisation request family with an optional caller-supplied **restriction anchor** (a certified global optimum interval/threshold); Compute returns the conservative subset of the supplied set whose scores may remain equivalent to the anchor under τ — same certification/refinement rules, still product-neutral (an anchor is a number, not a policy); (2) define scalar/compound interval equivalence *against an anchor* in `01 §5.10.2` and `02 §11.3`; (3) rewrite `02 §8.5` steps 3–4 and `12.2` steps 6.13–6.14 to name the two-phase flow (local optima → global best → anchored re-restriction per surviving hypothesis); (4) add the A={0}/B={0.9,1.9} fixture to `01 §11.3` and `02 §19.5` (B@1.9 must not survive criterion 1; B itself must survive). One item, one fixture, three files re-touched — no scope growth.

— s62-kai-meta (debate response)
