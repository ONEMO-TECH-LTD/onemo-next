# Round 6 — Meta audit of GPT Pro's delivered engine (onemo-magnetic-engine-v1.0.0)

> **SUPERSEDED IN PART BY R7 (grid-qa) — CORRECTION FILED 2026-08-16.** QA's Round 7 audit refutes
> four of this file's endorsements, and I reproduced all four myself before conceding:
> (1) "exact legality core" — FALSE as a safety claim: `discContainedExact` nearest-rounds the
> radius, so radius 12.004 at quantum 0.01 returns `legal:true` with **margin −0.004mm** — a
> negative-margin placement declared legal and `exactAtQuantum:true`.
> (2) "two-stage ManufacturingSpec with exact re-verification" — FALSE: a production-marked spec
> with `sourceGeometryHash` replaced by 64 zeros and `decisionTrace` erased, then re-hashed,
> **verifies as valid**.
> (3) "every hard-won spec rule is in the code" — FALSE for compound anchoring: with A=([0,0],[100,100]),
> B=([0.5,1.5],[0,0]), tau=(1,1), the anchor lets component-1-uncertain B decide on component 2 and
> **A is eliminated** — the exact R4 compound-uncertainty regression we wrote the rule to prevent.
> (4) profile identity is forgeable: a clone with `cellMm` changed 24→20 but the original hash kept
> is accepted, producing different results under the same claimed profile hash.
> My adversarial pass tested one failure family (geometric false/missed seat) and passed; QA tested
> safety rounding, identity forgery, evidence tampering and policy enforcement — where this build
> actually fails. **QA's verdict (FAIL — repair in place) governs; the endorsements below are to be
> read only as far as they survive that.** What stands: architecture/boundary, canonical polygon
> handling, the real-shape canon mismatches (F1), the 18–36s traces (F2), and the certified-path
> refusals (F3).

**Lane:** s62-kai-meta · 2026-08-16 · Dan-directed full audit
**Sources read in full:** every source file of all three packages (~2,875 lines: geometry-compute 1,480 · magnetic-logic 1,081 · magnetic-next 125 + tests 160 + cli-demo), both profile JSONs, all reports (benchmark, compliance matrix, known-limitations, implementation status), and the 20260816-1022 transcript tail (the 97-minute build turn, lines 5481–5933).
**Execution-backed:** shipped tests re-run in my own shell — **25/25 pass** (661ms, after `link-workspaces`). Engine probed with the real canon shapes (bat, butterfly, pill from the v3.2 fixture set, decimated to ≤3,500 verts to fit the 4,096 budget) — results below.

## Verdict

**The architecture and math are the best of any track — this is the R3 contract genuinely implemented, not paraphrased. But it is not a product engine today: its product calibration is placeholder-by-design, and its measured speed on real cutout traces is ~35 s/shape — worse than v3.2's sweep.** It is a parts source of the highest quality for Step 1 of the assembly, not a replacement for the assembly.

## What is genuinely excellent (verified in code, line-level)

1. **Exact legality core** (`containment.ts`/`clearance.ts`): integer-quantised BigInt predicates (`cross² ≥ r²·len²`, divide-free), closed tangency legal, one-quantum intrusion illegal — same exactness family as Grok's predicate, plus honest `EXACT` vs `CERTIFIED_APPROXIMATE` labels on every result.
2. **The certified continuous placement contract, implemented** (`adaptive.ts`/`optimization.ts`): quadtree over the translation domain with Lipschitz-certified box classification (centre clearance ± half-diagonal), INSIDE boxes proven feasible, witnesses re-proven by the exact predicate, and a true three-value outcome — FEASIBLE / INFEASIBLE_CERTIFIED / INDETERMINATE_WITHIN_TOLERANCE. This is the missing "finding" capability, working.
3. **Every hard-won spec rule from our five audit rounds is in the code** (`certified-solver.ts`/`optimization.ts`): global anchor + one-sided anchored restriction, symmetric candidate-candidate equivalence, "earlier components must be certified equivalent before a later criterion may decide", overlap-without-equivalence → DECISION_INDETERMINATE (never a guess). The QA counterexample numbers (0.9/1.9 vs anchor 0) are literally a shipped test.
4. **The mass measures Dan named as gap #1** (`halfplane.ts`/`directional.ts`/`components.ts`): exact half-plane clipping for cap area + first moment (real hanging-mass gravity), and the multi-clearance region hierarchy with persistence (majors/marginals) — implemented with a stated error envelope.
5. **The two-stage ManufacturingSpec** (`manufacturing-spec.ts`/`verifier.ts`): canonical-JSON SHA-256 identity, artifact/profile/geometry hashes, exact re-verification at fulfilment, and the tolerance policy (POST_TOLERANCE_MINIMUM_V1: verification radius = 12 + cut+placement+material+assembly) enforced at validation AND fulfilment — the exact question Dan was asked last night, both readings supported as policy.
6. **Honest self-reporting throughout:** the reference profile ships `productionReady:false` with every assumption named; fulfilment is BLOCKED rather than silently assumed; the 16ms miss and no-browser-verification are stated, not hidden; no invented Batwoman fixture.

## What fails — the two product-blocking facts

**F1 — Canon conformance fails at the calibration layer (probe, my run, real shapes):**

| Shape | Band | Dan's ruled canon | GPT engine answered |
|---|---|---|---|
| bat | B3 | tri-96-up (3-magnet triangle) | pair.vertical @120 ✗ |
| bat | B4 | pair-v-96 (sparse) | column.3 @168 (48-pitch) ✗ |
| butterfly | B3 | square-48 4-in-wings | pair.horizontal ✗ |
| butterfly | B4 | square-96 | **l.bottom-left** ✗ — an asymmetric L on a mirror-symmetric shape |
| pill | B2 | diagonal pair | **NO_SOLUTION** ✗ — no diagonal patterns exist in the set |
| B1s + orientation pairs | single high / pair follows shape | ✓ matches |

Root cause is not the math — it's the reference profile: no diagonal patterns, no 96mm sparse population (disabled pending PD-04), no symmetry law, no strip law, no band-count law, 12mm size rungs instead of snug sizes. All declared as placeholder assumptions by the package itself. **The two days of Dan's calibration living in v3.2's judge do not exist here.**

**F2 — Performance fails on real inputs (probe, my run):** bat 35.7s, butterfly 34.0s, pill 18.1s per all-band solve at real trace density. The shipped 49ms benchmark is a 12-vertex rectangle. Root cause read in code: **no spatial acceleration anywhere** — `clearanceAtPoint` is a linear scan over all edges, `preparePolygon` runs O(n²) exact self-intersection, and every candidate size re-prepares and re-rasterises the full polygon. v1's BVH + interval trees exist to solve exactly this and are absent here. Also: 4,096-vertex hard budget with "no silent simplification" — correct policy, but the simplification owner (with the conservative-envelope contract) is explicitly left upstream and unbuilt.

Minor: preview solver's point-scores label `status:'CERTIFIED'` on midpoint float comparisons — mislabeled for the preview path (the certified path is separate and honest); test coverage is thin relative to surface (25 tests / ~2,900 lines); browser/mobile evidence absent (self-declared).

## What this means for the assembly plan (custody note)

The Step-1 build ("v3.3 certified geometry + complete placement, clean implementation") now has a **reference implementation to take parts from instead of building from paper**: the adaptive feasibility engine, interval/anchor optimization, half-plane moment measures, region hierarchy, canonical hashing and two-stage spec are importable designs (dependency-free TS, honest labels). The composition that wins remains exactly the plan's: **v3.2's accelerated physics substrate (BVH/interval trees) + v3.2's calibrated law set + this delivery's certified-placement and mass-measure machinery + its spec/identity plumbing.** Neither engine alone is the product.

## Addendum — depth pass (the gaps the first pass had punted to QA, now closed by my own runs)

**Dist integrity + hash chain: PROVEN.** Rebuilt all three packages from the source I read; the shipped `dist/` trees are byte-identical to the rebuild, the rebuild reproduces the delivery's exact artifact hashes (`5da8574f…`, `65388c32…`), and the shipped ZIP SHA256SUMS match my own `shasum` of the archives. The compiled code IS the source I read; "read all code" is now discharged in full.

**All seven canon shapes walked** (preview path, ~3,000 verts each, 18–35s each). Full table in the probe log; the pattern across all seven: B1 singles correct; B2 pairs follow shape orientation correctly; **every shape's B3–B5 collapses to pair.vertical → column.3** (occasionally an asymmetric L). No squares, no rects, no 96 sparse, no diagonals — seven shapes, one degenerate answer family. Also bot B1 = 48mm (your open 44-vs-60 debate gets a third answer), poke1 B1 = 36mm. Confirms F1 as systemic, not per-shape: the mechanics ordering + placeholder pattern set produce a judge that has never met your rulings.

**Certified production path on a real trace: REFUSES — F3, new product-blocking finding.** `certifySizeSolution` on the real bat: 60mm → DECISION_INDETERMINATE (M03_UPPER_MOMENT uncertain, 23.3s); 96mm → DECISION_INDETERMINATE (M01_MAJOR_COVERAGE uncertain, 54.9s). The refusal is correct per contract (never guess), but it means **the production pipeline cannot currently emit a certifiable ManufacturingSpec for any real cutout** — the criterion tolerances (e.g. quantum×area for the moment) are far tighter than the adaptive refinement budget can prove on 3,000-vertex geometry. Certification works on toy rectangles (the shipped test), not on product shapes.

**Adversarial suite vs the placement engine: ALL FIVE ATTACKS SURVIVED.** (1) exact-width 24.00mm corridor: found the zero-area legal line exactly — 2,049 witnesses, all on-line, none off; (2) 23.98mm corridor: INFEASIBLE_CERTIFIED, zero false seats; (3) the Grok-killer concave notch: zero exact-illegal witnesses; (4) starved to a 200-cell budget on a 14-tooth comb: zero false witnesses; (5) hairline ±0.01mm seat window: found, all witnesses exactly legal. The placement core's no-false-seat/no-missed-seat discipline is real under attack — the defect class that disqualified Grok's collector does not exist here.

**Net effect on the verdict: unchanged in direction, sharpened in force.** The math core is now attack-proven, not just read-proven — strongest possible endorsement for taking it into Step 1. The product gaps are now three (calibration F1, real-trace speed F2, certified-path refusal F3), all measured, all fixable in the assembly: F1 by porting v3.2's calibrated laws into the profile/mechanics, F2 by v1's accelerated substrate, F3 by budget/tolerance calibration once F2 makes refinement affordable.

Necessity: no unnecessary elements found — no invented decisions, placeholders declared, WASM correctly dropped after its gate failed. Sufficiency vs "build the entire engine end to end": **architecture complete; product engine PARTIAL** — blocked by its own declared unresolved rows (calibration) and by F2 (real-trace performance), both of which it discloses. The delivery is what it claims to be, and what it claims to be is not yet Dan's engine.

— s62-kai-meta
