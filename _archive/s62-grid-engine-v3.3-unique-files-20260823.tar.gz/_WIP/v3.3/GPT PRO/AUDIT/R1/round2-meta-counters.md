# Round 2 — s62-kai-meta adversarial counters to round1-grid-qa-position.md

Scope: fresh transcript only (`ChatGPT-Grid and Band Logic-20260815-1054.md`), per Dan's ruling. Each QA objection challenged; verdict per point: SURVIVES / SURVIVES-REDUCED / FAILS.

## Point-by-point

**QA-1 (missing Dan approval gate before Turn 2) — SURVIVES-REDUCED.**
Counter: the plan's own Status line is *"CLEAR to execute Turn 1: specifications only"* — the CLEAR is already Turn-1-scoped, and QA's own §"strongest counter" concedes exactly this. So "the plan goes directly into Compute implementation" misreads the artifact: nothing in it authorises Turn 2. What genuinely survives is narrower: the plan never states an explicit approval gate *between* turns ("Four execution turns remain, assuming the governing scope is not changed" reads as a chain). Required fix is one sentence — each turn ends at a hold until the scope owner releases the next — not a BLOCKED-level structural defect.

**QA-2 (Emscripten absent, WASM locked without benchmark) — SURVIVES, with a correction both of us owe.**
This is my blocker too and it stands: promising a compiled artifact on a toolchain the plan's own probe shows missing is an untestable commitment. But the honest synthesis from my round-1 self-counter applies to QA as well: "no comparative kernel benchmark" cuts both ways — a TS fixed-point backend is *equally* unbenchmarked, and Clipper2's integer arithmetic is a **correctness** argument (the exact-tangency / 0.01mm-intrusion proof class), not just speed. The defensible requirement is not "don't use WASM"; it is "the first Turn-2 deliverable is proof the chosen backend builds and passes the tangency corpus in the actual environment, else fall back to the smallest buildable backend." If QA's position implies mandating TS, that part fails; the probe-first demand survives.

**QA-3 (offset approximation loses feasible placements; final validation can't recover them) — SURVIVES-REDUCED.**
Sharpest technical point in QA's round and I missed it. Counter-pressure on materiality, though: placements lost to arc approximation are by construction within epsilon of the feasibility boundary — zero-margin candidates that the blueprint's own noise rules classify as *marginal* and disprefer. Losing them is arguably conservative-by-design. Where it IS material: the **registration feasible region** — an over-tight approximated intersection can falsely fail *canonical* registration and push the shape into an unnecessary translation search, changing physical output for non-marginal reasons. Fix belongs in the system contract: mandate the approximation direction (strictly inward/conservative), a stated epsilon, and the rule that canonical registration is retried with the exact predicate before being declared infeasible. As a spec requirement it survives; as a "correctness overclaim" blocker it is reduced.

**QA-4 (no canon oracles: Batwoman B1 head / B2 vertical pair / B3 T as black-box acceptance) — SURVIVES OUTRIGHT. Strongest QA-only finding.**
No counter worth making. This is the exact standing law — gate against the proven reference, not an own-authored checklist. Dan's walkthrough (B1 single upper-head anchor, B2 vertical pair beating horizontal, B3 T: top single + bottom row of three) is the only ground truth that distinguishes "policy numbers that pass structural tests" from "the product." These must be encoded as required black-box outcomes in the Logic spec's test matrix, and threshold calibration must be *derived from* making the oracles pass, not asserted. I adopt this into the joint position; it was absent from my round 1.

**QA-5 (holes exclusion = unauthorized scope cut) — SURVIVES-REDUCED.**
Counter: "unauthorized" overstates the record. The exclusion appears verbatim in the Part A/B spec ("Initial scope excludes holes and disconnected silhouettes"), and Dan's next message was "ok we need to apply this and discuss actual math and code" — he built on the artifact containing the exclusion. That is not silence-as-consent being invented by the planner; it's a visible line in an accepted base. What survives: proceeding on a doc ≠ ratifying every clause, and this clause is product-material (Effects Studio users will draw letters and rings — counters are the common case, not the edge). So: not an "unauthorized cut," but a **named ratification item** Dan must explicitly rule on (reject-with-reason vs outer-boundary-only in v1) before the input contract freezes. Same disposition as my round-1 item 4b.

**QA-6 (premature fragmentation, ~30 submodules, duplicate boundaries) — MOSTLY FAILS.**
Counter: the module count is directive-driven — Dan verbatim: *"split it onto submodules so that it is not code mono block and has swappable parts."* Necessity judges whether *capabilities* should exist, not how files are organised; collapsing 30 file-level modules into 8 delivers the same code and violates the stated constraint's intent. The named "duplicates" don't hold up either: Compute `lattice` (neutral geometry generation from supplied spacing) vs Logic `cell-board`/`frames` (naming, parity, footprint policy) is precisely the neutrality boundary the whole architecture exists for; `clearance` vs `containment` is measurement vs predicate (containment ≡ clearance ≥ r, one is defined in terms of the other — a dependency, not a duplication). What survives: the system contract should carry one-line boundary statements for these adjacent pairs so an implementer can't blur them. That's a documentation line, not a shrink finding.

**QA-7 (creation timestamp breaks byte-determinism of ManufacturingSpec) — SURVIVES.**
Correct, cheap, and worth having: same input/profile/version must produce identical canonical content. Fix: timestamp (and any run metadata) lives outside the canonical/hashed payload. Adopted.

**QA-8 (magnet type/diameter and engine-artifact retention absent from spec) — SURVIVES-REDUCED.**
Counter on the first half: the blueprint *deliberately* abstracts magnet SKU (6/8/10mm all live inside the same 24mm envelope) — the engine's contract ends at centres + clearances, and forcing SKU selection into the engine would smuggle product/commerce policy into a geometry contract. But QA is right that the ManufacturingSpec is billed as "the production contract": it must therefore either carry the magnet spec or *explicitly state that magnet selection is a downstream fulfilment decision outside the spec* — silent absence is the failure. Engine-artifact retention (pinning the binary hash, not just a version string) survives fully — it was my round-1 item 4e; fulfilment re-verification is meaningless if the verifying artifact can drift under an unchanged version label.

**QA-9 (invented evidence: unmeasured gates, five-turn certainty, WebKit ≠ iPhone) — MOSTLY FAILS.**
Counter: the plan does not present the gates as measurements — it labels them "provisional gates before acceptance," commits to locking fixtures in the spec, and *itself* states WebKit automation "will not be falsely described as a physical iPhone benchmark." Calling self-declared acceptance thresholds "invented evidence" is the finding QA's own standard forbids: framing a non-problem as a defect. Turn-count is an estimate, and the plan conditions it ("assuming the governing scope is not changed"). What survives is the piece QA didn't name and I did: the gates were silently *loosened* from the previously stated targets (150–200KB→250KB, 2ms→4ms, 10ms→16ms) — re-baselining must be declared, or it's drift.

**QA-10 (audit self-deception; CLEAR unsupported) — HEADLINE FAILS, RESIDUE SURVIVES.**
The headline dies on the same fact as QA-1: the CLEAR is textually scoped to Turn 1 specs, and QA's own closing paragraph concedes that under that reading "most sufficiency objections become required contents of that turn rather than plan blockers." That concession is the correct verdict and should have been the position, not the appendix. Residue that survives: the necessity table does map labels to clauses without stress-testing minimality (QA is right that a mapping is not a test), and the sufficiency table points at future artifact names. But for a *plan* — as opposed to a delivery — pointing at named future artifacts with acceptance criteria is what sufficiency can mean; the real gate is whether Turn 1's actual specs satisfy them. Verdict: the plan's audit is thinner than it presents, but "self-deception" is not established.

**QA shrink-list stragglers — the "unrequired third integration ZIP" cut FAILS.**
Dan verbatim: each engine "packaged in the zip file to be downloadable," and the integration module is a mandated deliverable in the same directive set. Shipping the integration package un-zipped while the other two are zipped is an inconsistency, not a saving. (The plan's own cut of a *fourth combined* zip was the right one.)

## What the two rounds jointly establish

**Converged verdict: the plan is conditionally clear to Turn 1 only, behind the pre-Turn-1 feedback gate; nothing beyond Turn 1 is authorised.** QA's "BLOCKED" and my "not clear to run as written" are the same verdict at different labels — the operative content is identical: no Turn 2 without (a) buildability proof of the chosen backend, and (b) Dan's ruling on the flagged product-policy values.

**Joint blockers (both rounds, independent):**
1. Backend buildability must be proven before it is a commitment (WASM toolchain absent in the executing environment).
2. The 11 policy locks + holes ruling + top_direction are Dan's decisions and must land as flagged, veto-able values with rationale.

**Adopted from QA (absent from my round 1):**
3. Canon oracles — Dan's Batwoman walkthrough encoded as black-box acceptance tests; calibration derives from the oracles.
4. Timestamp excluded from the ManufacturingSpec canonical hash.
5. Offset-approximation contract: conservative-inward guarantee + exact-predicate retry before canonical registration is declared infeasible.
6. ManufacturingSpec must state magnet-SKU ownership (in or explicitly downstream) and pin the engine artifact hash.

**Standing from my round 1 (unchallenged by QA):**
7. Determinism tie-break for the continuous feasible region defined in the *system contract*, not the policy annex.
8. Circles/rounded-shape band rule; mixed-parity footprints; top_direction provenance.
9. Gate re-baselining declared.

**QA findings that do not survive:** module-count fragmentation (directive-driven), "invented evidence" framing (self-labelled provisional targets), "CLEAR unsupported" headline (textually Turn-1-scoped), integration-zip cut (directive-inconsistent), "unauthorized" framing on holes (visible in an accepted base; still needs ratification).

— s62-kai-meta
