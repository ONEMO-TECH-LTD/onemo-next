# Round 3 — s62-grid-qa synthesis after cross-counter

Scope: the fresh `ChatGPT-Grid and Band Logic-20260815-1054.md` transcript only.

## Corrections I accept from Meta

1. **The final status is expressly scoped to Turn 1.** My round-1 headline treated the four implementation turns as already authorised. That was too broad. The precise verdict is: the plan needs revision before Turn 1 is executed as written; no later turn is clear.
2. **The performance targets are provisional, not claimed measurements.** “Invented evidence” was the wrong charge. The valid concern is that the final plan loosens earlier proposed targets without explaining why. The five-turn count is an estimate Dan requested, not a proof claim.
3. **The holes exclusion is not invisible.** It appears in the preceding proposal and Dan then says “apply this.” I withdraw “unauthorised scope cut.” Because holes affect common shapes and the final plan must freeze an input contract, the specification should still state the consequence plainly; it is not an independent blocker if “apply this” is read as acceptance.
4. **The backend finding is probe-first, not TypeScript-first.** Neither implementation is proven. The contract should remain backend-neutral until a bounded build/correctness/payload probe establishes the smallest viable backend.

## Findings that survive

### 1. Turn 1 is still not executable as written

Turn 1 says eleven product-policy decisions “must be locked there.” Writing the specifications is authorised; silently deciding product behavior is not. Turn 1 must produce proposed values, rationale, canon evidence, and explicit unresolved markers. Product policy freezes only after Dan rules on them.

The plan also says implementation cannot begin before the contracts are approved, yet its execution section does not name that hold. Add the hold after Turn 1. This is a cadence correction, not a new programme.

### 2. Canon outcomes must govern calibration

The Batwoman walkthrough is the only supplied black-box truth for whether the Logic engine reproduces the intended product behavior: B1 upper/head anchor, B2 vertical pair, B3 T with one above and three below. These must be acceptance oracles. Thresholds and tie-breaks are derived or calibrated against them; a self-authored structural checklist is insufficient.

### 3. The backend promise precedes proof

The workspace probe reports no Emscripten, but the plan promises C++17 + Clipper2 + compiled WASM as the only implementation. Before the compute spec freezes that choice, prove the build in the actual delivery environment and test exact tangency, 0.01 mm intrusion, deterministic output, and compressed payload. If it fails, select the smallest backend that passes the same corpus. Do not build two production backends.

### 4. Approximate erosion needs a false-negative contract

The plan's exact final point validation prevents false-positive selected magnets; it does not recover feasible candidates removed by polygonal round-offset approximation. This is material at canonical registration because a false infeasibility result changes the chosen registration. The spec must define approximation direction and tolerance, and must retry the exact containment predicate before rejecting canonical registration.

### 5. Determinism and manufacturing handoff remain incomplete

- Select one point from a continuous feasible region with an explicit total order in the system contract.
- Keep timestamps and run metadata outside the canonical ManufacturingSpec payload/hash.
- Pin the exact engine artifact hash used to create and verify the spec.
- State whether magnet SKU/type/diameter is part of the production contract or a named downstream fulfilment input. Silent omission contradicts the claim that the spec is sufficient for physical repetition.
- Define `top_direction`, mixed-parity footprints, circle/rounded-shape behavior, and verifier failure semantics.

### 6. The necessity audit still overclaims minimality

Dan required submodules and swappable/editable parts; he did not require every named responsibility to become a separate module. “Submodules required” does not prove this exact decomposition is minimal. Adjacent pairs such as clearance/containment and lattice/cell-board may be valid boundaries, but the plan owes a one-line ownership rule and should merge any pair that has no independent swap or test seam.

The third integration package is required; a third ZIP is not explicit. “Each engine” grammatically applies to the Compute and Logic engines. Keep the Next integration deliverable, but package it separately only if download/distribution requires it. This is a small packaging shrink, not an architecture objection.

Embedding a necessity report in every package README duplicates governance prose. Put acceptance evidence where it is used; keep one plan-level necessity verdict.

## Round-3 verdict

**Necessity — shrink:** do not lock the sole backend before its probe; do not treat every responsibility as a mandatory module; remove repeated necessity prose; do not require a third ZIP without a distribution need.

**Sufficiency — partial:** Turn 1 lacks canon-governed calibration, product-decision ownership, the explicit post-spec approval hold, approximate-offset false-negative handling, complete deterministic ManufacturingSpec semantics, and several blueprint rules.

**REVISE before Turn 1.** The architecture direction survives. The plan becomes executable for Turn 1 after the corrections above are folded into that turn as specification requirements. Turn 2 remains held until the specifications and product-policy values are approved and the chosen backend passes the bounded probe.
