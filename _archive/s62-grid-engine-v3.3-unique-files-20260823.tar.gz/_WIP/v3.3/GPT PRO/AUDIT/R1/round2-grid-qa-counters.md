# Round 2 — s62-grid-qa counters to Meta

Source challenged: `round1-meta-position.md`.

## Counter 1 — Meta's framing imports the prior attempts into a deliberately fresh review

Dan corrected this explicitly: this is a fresh start and the transcript is the authority. Meta frames the artifact as a third attempt and uses the two failed engines to judge the plan. That contaminates the review. Prior failures can explain Dan's caution, but they cannot supply requirements, architecture, code-reuse duties, or a repository probe for this standalone GPT Pro delivery.

**Binding correction:** review the plan against the transcript's accumulated directives only. Delete the claim that integration owes a probe of prior engine code. GPT's `/mnt/data` probe is limited but honest for the standalone ZIP deliverable.

## Counter 2 — “Architecture and decomposition are sound” is not established

Meta credits the three-package split and roughly thirty engine submodules without testing whether a senior engineer would delete or merge them. The plan duplicates boundaries:

- Compute `lattice` versus Logic `cell-board` and `frames`;
- Compute `clearance` versus `containment`;
- Logic `profile-schema` versus `profile-registry`;
- Logic `patterns` versus `pattern-permissions`;
- Logic `mechanics` versus `selection`.

Dan required modularity, not maximal atomisation. Module boundaries should follow independently testable change axes proven in the specification, not nouns invented before code.

The third integration **module** is required; a third separately versioned package and ZIP is not explicitly required. The plan must justify independent distribution or keep the adapter/example beside the two engine packages.

## Counter 3 — the necessity audit is not genuine

It correctly cuts obvious absurdities, but it does not test the remaining elements against the minimal baseline. It asserts every surviving element is necessary because a future artifact has the same label. Its sufficiency table maps requirements to scheduled filenames rather than mathematical mechanisms or acceptance criteria. That is exactly a document grading itself.

The plan also says necessity findings will be copied into every package README. That duplicates a planning audit into three runtime artifacts after claiming it cut a separate report.

## Counter 4 — Meta misses the safe-core false-negative problem

Clipper2 round offsets approximate arcs. Direct containment rechecking prevents an approximate safe core from authorising an invalid selected point, but it cannot recover a valid feasible translation discarded by approximation. The specification needs a bounded/conservative error contract or an analytic feasibility proof. “Final recheck” alone is insufficient.

## Counter 5 — Meta misses determinism and manufacturing-contract defects

- `ManufacturingSpec` includes a creation timestamp while the blueprint requires identical input/profile/version to return identical output. Timestamp must be external metadata or excluded from canonical hashing.
- The retained physical contract does not name the actual magnet diameter/type despite exact production repetition being the purpose.
- Version strings and hashes are not enough unless the exact verifier binary/profile artifact remains resolvable at fulfilment time.

## Counter 6 — Meta understates performance and delivery gaps

Quiet re-baselining is not the main issue. Every payload/runtime threshold and the fixed five-turn schedule is unmeasured. They are hypotheses, not gates. Automated Chromium/WebKit plus a benchmark page proves compatibility, not mobile Safari/Chrome optimisation. Acceptance needs real reference-device observations.

## Counter 7 — Meta's TS-first prescription repeats the plan's mistake

Meta attacks an unproven WASM choice by preferring an equally unproven TypeScript choice. Its own counter concedes this. The lawful position is backend-neutral specifications plus one bounded implementation probe comparing the smallest viable candidates on correctness, payload, cold start and warm compute. The winner becomes the sole production backend; no dual runtime ships.

## Counter 8 — where Meta is right and Grid QA was initially too strict

The transcript explicitly authorises spec-first staging. The unresolved policy mathematics do not have to exist in the execution plan; Turn 1 may lawfully derive and propose them. Therefore `BLOCKED before Turn 1` is too strict if Turn 1 is only a draft-spec exercise.

The real cadence is:

1. Correct the plan's false backend lock and artifact bloat.
2. Execute Turn 1 specifications.
3. Hard product gate: Dan approves the eleven product-facing decisions and canon outcomes.
4. Only then execute implementation.

So Meta is correct that the plan shape can proceed into specification work after correction. It is wrong that the full decomposition is already sound or that the current `CLEAR` can authorize the chain beyond that gate.

## Round-2 verdict

- Meta survives on: unproven backend blocker, product-decision ownership, continuous-region tie-break, holes/top-direction/circle/verification gaps.
- Meta fails on: prior-attempt framing, architecture approval, audit credibility, TS-first prescription, and omission of precision/determinism/manufacturing/mobile defects.
