# Round 4 — orchestrator pressure-test

Scope: both Round-3 syntheses, tested against the fresh transcript.

## Ratified decisions

1. **REVISE, then Turn 1 only.** The current `CLEAR` is narrow, but Turn 1 itself still freezes product choices without owner approval.
2. **Spec-first and three-package direction survive.** Compute remains neutral; Logic owns versioned product policy; Next is the integration/handoff layer.
3. **Backend-neutral contract, bounded proof, one shipped backend.** Neither WASM nor TypeScript is preselected by assertion.
4. **Product choices are proposals until Dan approves them.** The eleven listed locks plus `top_direction`, holes behavior, circle behavior, and mixed-parity coverage remain visibly unresolved where evidence is insufficient.
5. **Module seams earn their existence.** Required modularity does not justify atomisation without independent ownership, swap, or test boundaries.
6. **Three ZIPs stay.** In GPT Pro's delivery channel the archives are the means of exporting all three deliverables; this is packaging, not a fourth architecture surface.

## Strongest counter to the joint synthesis

The joint pack risks replacing one false CLEAR with three subtler overclaims.

### 1. Three Batwoman outcomes are necessary but not a calibration corpus

B1/B2/B3 black-box outcomes prevent the implementation from drifting away from the supplied canon. They cannot by themselves determine structural thresholds, tie-breaks, or B4/B5 behavior. “Calibrate to make these oracles pass” invites overfitting.

Correction: make the three outcomes mandatory regression constraints. Require counterexamples and boundary fixtures for each proposed rule, and leave rules affecting uncovered bands/shapes unresolved for Dan rather than inferring them from three examples.

### 2. Exact retry only at canonical registration does not close all approximation false negatives

A conservative polygonal erosion can also erase a feasible noncanonical registration or alter structural-region measurements. Exact final containment cannot recover a candidate that enumeration never produced.

Correction: the spec must quantify the approximation error relative to manufacturing precision and define how boundary-near decisions are resolved. At minimum: exact retry before any no-feasible-registration result, not only canonical rejection; adaptive refinement or an exact predicate for any decision whose result changes within the error envelope; explicit acceptance if sub-tolerance false negatives are intentionally treated as marginal. “Conservative inward” alone is not exactness.

### 3. A downstream magnet input is not yet a repeatable ManufacturingSpec

The Compute engine may remain ignorant of magnet SKU. But a production contract cannot reproduce the physical object while omitting the physical component. Saying “downstream fulfilment owns it” only relocates the gap.

Correction: the final canonical production handoff must include a versioned magnet component reference and the diameter/thickness/tolerance fields that affect the geometry or assembly, whether Logic supplies them initially or fulfilment completes and re-hashes the spec before manufacture.

## Determinism correction

The canonical identity condition must be:

`same canonical input + profile hash + engine artifact hash -> byte-identical canonical output`

An engine version string is descriptive metadata, not sufficient identity. Timestamps and run metadata stay outside the hashed payload.

## Final necessity and sufficiency verdict

**Necessity — shrink:** backend lock before proof; module atomisation without a real seam; duplicated necessity prose. No further package or ZIP cut survives.

**Sufficiency — partial:** the Round-3 list stands, strengthened by three requirements: canon tests must not become the sole calibration corpus; approximation handling must cover every result-changing boundary case and no-solution result; the final production handoff must contain a resolved magnet component specification.

**FINAL VERDICT: REVISE, then Turn 1 only.** Turn 1 may draft the contracts and proposed policy values after this feedback is incorporated. Turn 2 remains blocked until Dan approves the product rules and the backend probe produces a buildable, deterministic, precise, payload-compliant winner. Product-policy approval remains Dan's decision; the technical backend winner follows the recorded probe.
