# Round 4 — s62-kai-meta final response (survive/fail)

## Counter 1 — Batwoman outcomes are regressions, not a calibration corpus: **SURVIVES**

Correct, and my R2/R3 wording ("thresholds calibrated to make the oracles pass") invited exactly the overfitting QA names. Adopted: B1/B2/B3 are mandatory black-box regression constraints; every proposed rule ships with counterexample and boundary fixtures; rules governing bands/shapes the canon doesn't cover stay explicitly UNRESOLVED for Dan. One guard added: the canon outcomes remain the only *supplied* truth — any additional fixtures GPT authors are themselves proposals for Dan's approval, never a self-authored authority that outvotes the canon. Otherwise "insufficient corpus" becomes a license to invent one.

## Counter 2 — exact retry at canonical only is incomplete: **SURVIVES**

Correct. A conservative erosion can erase feasible noncanonical registrations and shift structural measurements; final containment cannot resurrect candidates enumeration never produced. Adopted in full: exact retry before ANY no-feasible-registration result; approximation error quantified against manufacturing precision; any decision whose outcome flips within the error envelope resolved by exact predicate or adaptive refinement; sub-tolerance false negatives may be declared marginal-by-design only as an explicit, stated acceptance. QA's own third clause is the pragmatic default — exactness spends only where results change.

## Counter 3 — downstream magnet input ≠ repeatable spec: **SURVIVES**

Correct; my "state ownership, possibly downstream" relocated the gap rather than closing it. Adopted with QA's own two-stage allowance: the engine-produced spec may omit SKU (Compute/Logic stay geometry-pure), but the artifact physically manufactured against must carry a versioned magnet component reference (diameter/thickness/tolerance where they affect geometry or assembly) — fulfilment completes and re-hashes before manufacture. The final canonical hash covers a complete physical product, or the "exact repetition" claim is false.

## Determinism correction — artifact hash as identity: **ALREADY ADOPTED, CONVERGENT**

This is item 7b of the joint pack as written ("pin the exact engine artifact hash (not just a version string)"). QA's restatement sharpens the identity equation — `canonical input + profile hash + engine artifact hash → byte-identical canonical output`, version strings descriptive only — and that exact formula goes into the pack verbatim. No disagreement existed.

## Close

Nothing in Round 4 fails. All three counters strengthen the sufficiency list without touching the verdict: **REVISE, then Turn 1 only; Turn 2 double-gated on Dan's product approval and the recorded backend probe.** Feedback pack updated to v3 with these four amendments (items 4, 6, 7). Divergence register stands at zero — the third ZIP was ratified in QA's R4 §6. Debate closed.

— s62-kai-meta
