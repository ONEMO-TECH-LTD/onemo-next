# [s62-kai-meta] Independent position — GPT Pro grid-engine plan (Round 1)

Source reviewed in full: `_WIP/v3.3/GPT PRO/ChatGPT-Grid and Band Logic-20260815-1054.md` (all 4,706 lines; first 3,918 verified byte-identical to the earlier 10:32 export, so the new material is the final `/o-necessity --plan` response only).

## Framing

The plan is the third attempt at this engine. The two prior failures shared one root cause: the problem was treated as generic geometry optimisation ("find best magnet subsets for a polygon") instead of Dan's actual product law ("the shape conforms to ONEMO's fixed magnetic architecture"). The conversation preceding the plan fixed the conceptual model — safe core, structural persistence, parity registration, feasible-translation-by-intersection, neutral-kernel/policy-profile split. The plan should therefore be judged on one question: **does it faithfully operationalise that settled model with the smallest testable delivery, or does it re-smuggle risk in through execution choices?**

## Verdict

**The architecture and decomposition are sound — approve the shape. The execution plan is NOT clear to run as written.** Two blockers and several must-state items before Turn 1 is authorised.

## Strongest objections

1. **BLOCKER — the WASM backend commitment is an unproven-toolchain promise, and the plan documents its own evidence against it.** Its environment probe (§3) reports `Emscripten: not currently installed`, then Turn 2 promises "compiled WASM and ESM loader" as the *only* production backend ("one production backend, not WASM plus a second JavaScript fallback"). That is committing two turns ahead to a build it has never demonstrated it can produce. It also inverts probe-before-architecture: the workload is tiny (few-hundred-vertex cutouts, ≤25 nodes, a handful of candidate sizes) and no benchmark exists showing pure TypeScript with fixed-point integers misses the gates. The backend interface it already specified makes TS-first free; WASM should be a *benchmarked escape hatch*, not the baseline. If Turn 2 arrives with a WASM binary we cannot rebuild, the "portable, reproducible" claim is dead on delivery.

2. **BLOCKER — the 11 "product-policy decisions to lock in Turn 1" are Dan's decisions, and the plan assigns them to itself.** Band-boundary ownership, size sequence, registration discreteness, translation domain, strong/marginal thresholds, the pattern library and per-band permissions, mechanical priority order, tie-breaks, rounding — every one changes what a customer's physical product looks like. The plan says it will "lock" them inside the spec. Per our own gate discipline these must be surfaced as flagged, veto-able choices with one-line rationale, not settled constants buried in a 1,000-line spec. Silent Turn-1 lock = the exact drift mode that killed engines 1 and 2, relocated from code to spec.

3. **Determinism vs the continuous feasible region is still open and load-bearing.** The intersection-of-shifted-safe-cores result is a *region*; manufacturing needs one point. The tie-break that selects the single registration is listed as a to-lock item but is the difference between "deterministic engine" (a hard requirement, §19 of the blueprint) and "engine that happens to be deterministic on the shapes we tried." It deserves explicit mathematical definition in the system contract, not the logic spec's policy annex.

4. **Sufficiency gaps carried over from the blueprint that the plan never closes:** (a) `top_direction` provenance — canvas-up vs user-set; every gravity rule depends on it; (b) holes/disconnected silhouettes excluded from v1 while the Effects Studio's actual users will draw letters and rings — v1 behaviour (reject-with-reason vs outer-boundary-only) is unstated in the input contract; (c) circles/rounded shapes — bands are square-referenced and the early "circle needs padding" remark was never resolved into a rule; (d) `verifyManufacturingSpec` failure semantics at fulfilment (engine-version drift; binary hash vs version string).

5. **Quiet gate re-baselining.** Bundle target moved 150–200KB → 250KB (hard reject 500KB), warm solve 2ms → 4ms, all-band 10ms → 16ms, between the 10:13 response and the plan. Individually fine; done silently it is drift. The spec must state the re-baseline and why.

6. **Minor: the "greenfield" probe is of GPT's sandbox, not our tree.** Correct for its environment and it rightly doesn't claim to modify our repo — but our side must not read "no source implementation has been supplied" as "no prior art exists." The two dead engines and the v3.3 worktree exist here; whoever integrates owes a probe of our tree before accepting "greenfield" framing for the integration package.

## What the plan gets right (credit where due)

The necessity audit is genuine, not theatre: it cut the worker-by-default, dual backends, the fourth zip, the separate necessity report, AI recognisers and physics sims — all correct cuts. Spec-before-code with a shared system contract as the single drift-prevention artifact is the right ordering. The three-package split matches the settled model exactly, and the profile immutability rules (hash, version, never silently recompute old orders) are the strongest part of the whole plan.

## Strongest counter to my own position

On objection 1: WASM-first is not irrational. Clipper2's integer-coordinate robustness is a *correctness* argument, not just a speed argument — a hand-rolled TS erosion/intersection over floats is exactly where hairline tangency bugs (the "0.01mm intrusion" class) breed, and the plan's own required proofs demand exact tangency acceptance. A TS backend would need its own fixed-point Boolean-ops implementation or a JS Clipper port, which is not obviously less work or less risky than compiling the reference C++ everyone trusts. And my "workload is tiny" claim is itself an unbenchmarked assertion — the same sin I'm accusing the plan of. The honest synthesis: neither backend is proven; the requirement should be *demonstrate the chosen backend builds and passes the tangency/perf proofs in Turn 2's first deliverable*, not *mandate TS*. If Emscripten installs cleanly in its environment, my blocker reduces to a sequencing note.

On objection 2: a counterparty could argue Dan explicitly delegated ("plan execution first… self-audit… follow o-necessity") and re-surfacing 11 decisions is the manufactured-question failure. I hold the line anyway: delegation of *planning* is not delegation of *product values*; the cheap middle is decided-with-rationale-and-veto-window, which costs Dan one read, not eleven questions.

— s62-kai-meta
