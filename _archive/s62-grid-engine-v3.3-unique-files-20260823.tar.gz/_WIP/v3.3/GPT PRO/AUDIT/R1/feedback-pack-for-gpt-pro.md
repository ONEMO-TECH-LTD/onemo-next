# Feedback pack for GPT Pro — joint verdict after adversarial peer review (s62-kai-meta + s62-grid-qa)

Paste into the GPT Pro chat. Supersedes any earlier pack.

---

Your plan was adversarially reviewed by two independent reviewers over four rounds. Joint verdict: **REVISE, then Turn 1 only.** The three-package architecture and spec-first ordering survive. Fold the following into the plan and Turn 1 before executing anything.

## Cadence corrections (revise the plan text)

1. **Add explicit holds to the execution section.** After Turn 1: a hard product-approval gate — no Turn 2 until the scope owner rules on the flagged values below. Before the compute spec freezes a backend: the probe in item 3. State both holds in the plan; "assuming the governing scope is not changed" is not a gate.

2. **Convert Turn 1's "product-policy decisions that must be locked there" into PROPOSED values.** For each of the 11 (band-boundary ownership, size sequence, registration candidates, discrete/continuous registration, translation domain, strong/marginal thresholds, pattern library, per-band permissions, mechanical priority order, tie-breaking, coordinate rounding): present the proposed value + one-line rationale + supporting canon evidence + an explicit UNRESOLVED marker where you are not confident. Product policy freezes only when the scope owner approves. Do not bury values as settled constants.

3. **Backend: probe before lock.** Your own environment probe shows Emscripten is not installed, yet Turn 2 promises compiled WASM as the sole backend. Keep the specs backend-neutral behind the interface you already defined. Then run one bounded probe comparing the smallest viable candidates (C++/Clipper2→WASM if you can actually build it in your environment; TypeScript fixed-point otherwise/also) on: builds-in-environment, exact tangency accepted, 0.01mm intrusion rejected, deterministic output, compressed payload, warm compute on the reproducible corpus. The winner ships as the single production backend. No dual runtimes; no unverifiable build recipes.

## Turn 1 specification requirements (sufficiency gaps)

4. **Canon regression constraints.** Encode the Batwoman walkthrough as mandatory black-box regression tests the Logic engine must pass: B1 → single upper/head anchor; B2 → vertical pair preferred over horizontal; B3 → T (one top anchor + bottom row of three). These three outcomes are constraints, NOT a calibration corpus — do not overfit thresholds to them. Every proposed rule ships with counterexample and boundary fixtures; rules affecting bands/shapes the canon does not cover stay explicitly UNRESOLVED for the scope owner. Fixtures you author are themselves proposals for approval, never a self-authored authority that outvotes the supplied canon.

5. **Determinism identity.** The feasible-translation region is continuous; manufacturing needs one point. Define the exact total order selecting the single registration (e.g. nearest-to-canonical, then lexicographic) in the SYSTEM CONTRACT, not the policy annex. Identity condition: same canonical input + profile hash + engine ARTIFACT hash ⇒ byte-identical canonical output. Version strings are descriptive metadata, never identity.

6. **Approximation false-negative contract.** Final exact containment prevents false positives but cannot recover feasible placements lost to round-offset approximation — canonical AND noncanonical, plus structural measurements. Require: strictly conservative-inward approximation with tolerance quantified against manufacturing precision; the exact containment predicate re-tests before ANY no-feasible-registration result (not only canonical rejection); any decision whose outcome changes within the error envelope resolved by exact predicate or adaptive refinement; sub-tolerance false negatives may be treated as marginal-by-design only as an explicit stated acceptance; exact containment remains the sole legality proof for selected centres.

7. **ManufacturingSpec canonicalisation.** (a) Timestamps and run metadata live OUTSIDE the canonical hashed payload. (b) Pin the exact engine artifact hash used to create and verify the spec, and require the verifying artifact to remain resolvable at fulfilment time; define verifier failure semantics on drift. (c) The engine-produced spec may omit magnet SKU (the engines stay geometry-pure), but the final artifact manufactured against MUST carry a versioned magnet component reference (diameter/thickness/tolerance where they affect geometry or assembly) — fulfilment completes and re-hashes the spec before manufacture. The final canonical hash covers a complete physical product; "exact physical repetition" is otherwise a false claim.

8. **Blueprint residue — answer in the Turn 1 specs:**
   a. `top_direction`: editor-canvas "up" always, or user-settable per effect? It drives every gravity rule.
   b. Holes/disconnected silhouettes: the v1 exclusion was visible and built upon, but users will draw letters and rings — state the v1 consequence in the input contract (reject with machine-readable reason vs outer-boundary-only) as a flagged item for scope-owner ratification.
   c. Circles/rounded shapes: bands are square-referenced; state how a circle's band and canonical footprint derive.
   d. Mixed-parity rectangular footprints (1×3, 2×3): confirm parity registration and pattern permissions cover them, including single-axis translation search.

9. **Module seams.** For each adjacent module pair (clearance/containment, lattice/cell-board+frames, profile-schema/profile-registry, patterns/pattern-permissions, mechanics/selection): one-line ownership rule in the system contract; merge any pair with no independent swap or test seam. Modularity was required; maximal atomisation was not.

10. **Housekeeping.** Declare that the performance gates were re-baselined from the earlier stated targets (150–200KB→250KB, 2ms→4ms, 10ms→16ms) and why. Keep ONE plan-level necessity verdict; do not duplicate necessity prose into three package READMEs — package acceptance sections carry acceptance evidence only. Three ZIPs stand (the delivery channel requires downloadable archives for every deliverable).

## Then

Execute Turn 1 (specifications only) with the above folded in. Stop at the product-approval hold.
