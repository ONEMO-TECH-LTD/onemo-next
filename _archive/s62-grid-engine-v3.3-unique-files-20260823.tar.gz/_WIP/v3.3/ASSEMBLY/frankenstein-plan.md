# The assembly plan — v3.2 operational base → v3.3 production destination

**Custody:** s62-kai-meta · reframed 2026-08-15 per Dan's direction via QA's architecture proposal
(`AUDIT/R1/round1-grid-qa-architecture-direction-proposal.md`) — **this supersedes the earlier
"three-track Frankenstein" framing.** Source attribution lives in the implementation ledger; it
does not define architecture. History: the original composition and its QA-adjudicated revisions
are in this file's git history and `AUDIT/R1/`.

## The direction in one line

```text
v3.2 operational base + v3.3 production architecture built into it behind gates
```

- **v3.2 is the base:** byte-verbatim v1 physics, the production validation door, the running
  bench, band plumbing, repaired guards, and the fixture-gated **provisional** judgement.
- **v3.3 is the destination:** certified complete placement, approximation/tolerance contracts,
  deterministic decision semantics, profiles/artifact identity, rejection reasons,
  ManufacturingSpec — per the reviewed R3 contracts.
- **Grok is rejected from this build; its prior findings remain audit evidence** (team technical
  call, 2026-08-15 — rationale and history in `AUDIT/R1/` and this file's git history).

## The directive's deliverables (unchanged)

(a) mobile-first fast (ms–sub-second, Safari/Chrome) · (b) super-precise (no missed/false seats)
· (c) portable package the effects-engine repo imports · (d) powers the studio · (e) powers the
manufacturing spec (exact reproducible output).

## One production authority per operation

v1 validation = legality authority (until an equivalence-approved replacement lands) · v3.3
contracts = placement + determinism · **Dan-authoritative fixtures = canon** (a fixture written
to match current output is consistency evidence, never canon).

## Sequence — each step ends with: tests green → canon fixtures pass → eyes on the bench → snapshot pushed

### Step 0 — v3.2 base repairs + Dan-authoritative canon gate ✅ mostly landed
All audit repairs, the canon gate (7 shapes), behavioural counterexamples (8 laws, each
independently sourced to a contract or ruling), named repair regressions, and boundary fixtures
are landed (86/86 green at QA's closure audit @ 979b4d99, meta-verified by own runs).
**Boundary coverage is PARTIAL, not universal** (QA closure audit): the suite covers the named
pure thresholds only — the below/on/above claim does not yet extend to every threshold, four
count-valued guards accept fractions, and the fallback test proves hold-lawfulness without
proving the fallback path executes. These three narrow gaps are builder-owed Step-0 closure
items. **Open:** the gate becomes Dan-authoritative only when his seven canon rulings re-pin the
fixture families (`canon-adjudication/README.md`, with Dan).

### Step 1 — v3.3 certified geometry + complete placement (the build's core)
Implement the certified placement contract: safe-core erosion, feasible regions (intersection of
shifted safe-cores, Clipper2 in-repo), the conservative-approximation envelope (any simplified
outline provably between the true region and a stated shrunk one — both engines, no
exceptions), zero-width feasibility, and the interval/anchored-equivalence comparison semantics
from the R3 contracts. Clean implementation — no donor work. **The old 2mm sweep stays as the
A/B oracle until this step passes correctness, canon, and performance gates — only then is it
deleted. No parallel production path survives.**

### Step 2 — fixture-gated judgement on the complete candidate surface
The v3.2 judge is **explicitly provisional**: re-verify every law on the complete candidate set;
recalibrate or replace mechanics only through Dan-authoritative canon + counterexamples; new
lawful arrangements Dan hasn't ruled on get shown, not suppressed. Moment/region mechanics enter
scope here if (and only if) Dan's canon rulings or counterexamples demand them.

### Step 3 — cut the portable package from the proven live subgraph
`@onemo/grid-engine`: the live kernel + certified placement + judge + spec + bridge door. Trim
`geometry-truth` to the tolerance constant; drop `types.ts` product baggage; dormant v1 surface
stays in the bench tree and is named. Separation guard extends to the package boundary (no `@/`
imports). The bench becomes the package's first consumer.

### Step 4 — deterministic output contracts
ManufacturingSpec JSON (schema version, policy signature + judge-law hash, exact anchors,
registration, wrap/coverage verdicts; deterministic serialization, no timestamps in the payload)
+ machine-readable rejection reasons per band/size (R3 taxonomy subset).

### Step 5 — production gates
Performance on the real mobile targets, byte-determinism across runs, and the real-surface
visual gate. Dan's bench review points: end of Step 1 (same canon, certified placement, new
speed) and Step 4 (the spec output).

## Completion semantics

Tests passing / package building close **nothing** by themselves: every block closes only on its
original v3.3 acceptance criteria. Canon fixtures passing current output ≠ Dan-authoritative
canon complete.

## Necessity verdict
No unnecessary elements: no donor work, no adapters around proven-unsafe code; validated v3.2
code is retained, genuinely new v3.3 capability is built once.

## Sufficiency verdict
Delivers the directive in full: (a) Step 1+5 · (b) Step 1 (certified, provable) · (c) Step 3 ·
(d) Steps 2–3 · (e) Step 4.

## Execution notes
- Build in the v3.2 worktree. Snapshot commit + push per step.
- Gates: QA adversarial at every step boundary; meta necessity/sufficiency per step; canon
  fixture failure blocks any merge; nobody self-clears their own gate.
- **Nothing past Step 0 starts before Dan's seven canon rulings and his go.**
