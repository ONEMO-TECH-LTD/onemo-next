# Grok donor extraction proposal

**Recommendation:** extract two bounded implementation ingredients and the behavioral-test style. Do not transplant Grok's engine or candidate pipeline.

## Proposed donor set

### 1. Exact disc-fit kernel — evaluation status only

Candidate source from `measure.ts`:

- `PreparedOutline`
- outline quantization/preparation
- point-in-polygon internals
- squared segment-clearance comparison
- `discFits`

Required adaptation before production authority:

- full outer-ring input; `thinForFit` is forbidden
- hole support
- explicit coordinate quantum and tangency/tolerance contract
- resource bounds
- equivalence/adversarial suite against v1's current validation oracle

Initial role: independent reference oracle. It does not replace v1's production legality authority until equivalence is proved.

### 2. Bounded arrangement grammar

Candidate source from `enumerate.ts`:

- arrangement/family types
- population-coordinate conversion
- `registrationOf`
- run, rectangle, corner-triangle, T and window generators

Required adaptation:

- all caps become explicit governed inputs or named released-vocabulary limits
- emitted registration comes from arrangement parity, never lattice origin
- output is topology only: family + lattice-relative sites + parity
- no legality, size, band, origin, ranking or product-offer decisions
- regression fixture checks parity for every emitted candidate
- exclusions are listed; bounded enumeration is never described as complete enumeration

### 3. Behavioral-test style

Reuse synthetic counterexample patterns: top-heavy mass, two lobes, spike, notch, sparse population and determinism. Each fixture must be independently sourced to a contract or Dan ruling; a fixture written to match current output is consistency evidence, not canon authority.

## Explicit non-donors

- `candidates.ts` as a module
- `thinForFit`
- `smallestWhere` as correctness or completeness proof
- origin-derived registration
- Grok `select.ts`
- Grok spec, bridge, engine wrapper and UI
- approximate clearance/centroid/max-clearance helpers where v3.2 already owns the operation

`smallestWhere` may be evaluated later as an accelerator behind certified complete placement. It never discharges the no-missed-seat requirement.

## Integration boundary

```text
v3.3 certified placement contract
  -> bounded arrangement grammar proposes topology
  -> arrangement-derived parity
  -> v1/v3.2 validation door proves every emitted construction
  -> fixture-gated v3.3 judgement contract
```

## Status rule — extraction never closes a block

`DONOR EXTRACTED` means code has been isolated for evaluation. It does not mean the surrounding capability, contract, phase or engine block is complete.

Every extracted part reports these states separately:

```text
Donor extraction: complete/incomplete
Contract adaptation: complete/incomplete
Correctness proof: complete/incomplete
Product integration: complete/incomplete
Canon verification: complete/incomplete
Parent phase/block: complete/incomplete
```

Copying, compiling, donor tests or matching current outputs cannot close the parent block. The block closes only when its original v3.3 acceptance criteria pass.

## Necessity and sufficiency

**Necessity:** two code ingredients plus test patterns are the smallest defensible donor set. Importing the collector, search, judge or Grok architecture adds known defects and duplicate ownership.

**Sufficiency:** extraction alone is intentionally insufficient. Certified geometry, complete placement, formal judgement, product output and Dan-authoritative canon remain owned by the revised assembly plan.
