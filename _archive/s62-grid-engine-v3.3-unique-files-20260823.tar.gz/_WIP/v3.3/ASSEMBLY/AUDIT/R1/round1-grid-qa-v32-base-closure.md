# v3.2 operational-base closure audit

**QA snapshot:** `979b4d996a580ab9fefb0275ad303ca71f827e5a` in an isolated clean worktree.

**Verdict:** REVISE — the repaired v3.2 engine is the right operational base, but Step 0 is not closed. The principal code repairs survive independent execution. Three small test/guard gaps and Dan's canon ruling remain.

## What independently passed

- Full suite: **86/86** at the QA snapshot, 323.40s.
- TypeScript: `tsc --noEmit` passed.
- Real bench: port 3065 was served from the isolated QA worktree at the exact snapshot. All seven saved shapes were solved through the real UI; the 28 band answers matched the executable canon fixture. QA captured every offered frame. Representative observed results: Batwoman B1 `60/single`, B2 `88/pair-v`, B3 `146/tri-96-up`, B4 `170/pair-v-96`; Butterfly B4 `180/square-96`; Poke1 B4 `172/rect-48x96`; Poke2 B4 `188/rect-48x96`.
- Strip connectivity is single-linkage, including the ruled 107.3mm link and rejected 135.8mm fling.
- The half-resolution sweep exception is gone.
- Fallback implementation relaxes preferences only; hold laws remain gates and `NONE` is an honest result.
- Released templates, steps, and coordinate tuples are deeply frozen.
- Geometry measurements live in `compute/structure.ts`; judgement consumes measures and guarded values.
- The comparator is equality-safe and deterministic.
- Former judgement literals `72`, `24`, and `40` are guarded spec values; the 108mm label now identifies the 48x96 mixed-step diagonal.
- Four dead calibration knobs are removed; `maxTestedMM` now caps the sweep.
- Canon, behavioural, repair, and boundary harnesses exist and execute.

## Remaining findings

### F1 — count-valued guards accept fractions

`positionsPerAxis`, `optionsPerBand`, `structureScanlines`, and `massFieldSamples` describe counts, but their writers enforce only finite min/max bounds. An independent probe passed `8.5`, `1.5`, `8.5`, and `8.5`; all four were accepted. Evidence: `spec.ts` lines 90–128 and 404–443.

**Smallest fix:** refuse non-integers for those four keys and add named acceptance/refusal tests. If fractional values are intentionally meaningful, rename/retype and state those semantics instead; current count wording does not permit them.

### F2 — fallback regression does not prove fallback execution

`repairs.test.ts` lines 78–113 proves only that any returned winner obeys hold laws. It never establishes that the fallback branch ran. The test would still pass if fallback were deleted or if the ordinary candidate path supplied every result.

**Smallest fix:** add a fixture with a demonstrable precondition that the preferred path is empty and assert the fallback result or honest `NONE`, while retaining the hold-law assertions. A reason/trace field is acceptable only if already part of the output contract; do not add production instrumentation solely for this test.

### F3 — boundary-fixture completion claim is overstated

The file headline and assembly Step 0 say every pure threshold has below/on/above coverage. The file does not do that:

- filled-block quantization: below and above, no exact case (`boundary-fixtures.test.ts` lines 35–53);
- mirror symmetry: below and above, no exact case (lines 55–68);
- waist ratio: exact only, no below/above behavioural decisions (lines 70–83);
- structure taper, diagonal, and mass classification thresholds: writer bounds only, not decision-boundary tests;
- solve-level boundaries are explicitly deferred to certified placement (lines 1–5).

**Smallest fix:** either add the missing pure predicate/classifier cases and narrow the claim to the actual covered set, or remove the universal completion wording. Keep solve-level cases explicitly in Step 1.

### F4 — canon harness is engineering-complete, not Dan-authoritative

The seven-shape fixture and 28 UI answers are internally consistent at the snapshot. They freeze the current engine result; they become canon only after Dan rules the seven adjudication families. The plan already records this open item correctly.

## Assembly-plan audit

`frankenstein-plan.md` now has the correct architecture: v3.2 operational base, v3.3 production destination, Grok only as an optional leaf donor under an admission rule. Certified placement precedes package extraction, and the old sweep remains an A/B oracle until Step 1 passes correctness, canon, and performance. This is materially safer and simpler than the superseded equal-track assembly.

Corrections still required:

1. Step 0 lines 50–55 must mark boundary fixtures **partial**, not landed below/on/above every pure threshold.
2. `collaboration-plan.md` line 8 still describes the superseded Phase-1 Grok kernel transplant and early sweep deletion. Replace it with the new Step 0–5 sequence and donor admission rule.
3. Line 12 says Phase 4; use Step 4.
4. Line 43 says Dan's decisions do not block Phases 0–3, contradicting line 35 and the governing plan's “nothing past Step 0” hold. Delete that clause and use the explicit Step 0 hold.
5. The twin-oracle paragraph should describe Grok only as an optional falsifier if it becomes same-input conformant; a Grok judge rebuild is not a prerequisite or planned production track.

## Status matrix

| Area | Status |
|---|---|
| Connectivity, full sweep, fallback implementation, freezing, separation, comparator, guarded literals, dead-knob removal | VERIFIED |
| Count-value guard completeness | REVISE — F1 |
| Fallback branch regression | REVISE — F2 |
| Universal boundary-fixture claim | PARTIAL — F3 |
| Seven-shape engineering fixture | VERIFIED |
| Dan-authoritative canon | OPEN — F4 |
| v3.3 certified placement/runtime | PLANNED — Step 1, not built |
| Portable package | PLANNED — Step 3, not built |
| Deterministic ManufacturingSpec/reasons | PLANNED — Step 4, not built |

## Necessity

**No architecture expansion is needed.** Keep the repaired v3.2 base and make only F1–F3's narrow corrections plus the truthful plan edits. Do not transplant Grok wholesale and do not add a second production path.

## Sufficiency

**Partial.** The current base is sufficient to start from after F1–F3 and Dan's canon rulings, but it is not the v3.3 engine. Steps 1–5 remain required for certified completeness, portability, deterministic manufacturing output, and production performance.
