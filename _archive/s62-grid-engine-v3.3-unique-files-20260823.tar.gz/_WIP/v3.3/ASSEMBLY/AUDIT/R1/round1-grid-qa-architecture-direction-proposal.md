# Architecture direction proposal — v3.2 base, v3.3 destination

## Recommendation

Stop describing the implementation as three equal engines being assembled.

The production direction is:

```text
v3.2 operational base
  + v3.3 production architecture built into it behind gates
  + optional Grok leaf algorithms only where adaptation is smaller than a clean implementation
```

- **v3.2 is the base:** retain the byte-verbatim v1 physics, production validation door, running bench/integration, band plumbing, repaired guards and fixture-gated provisional judgement.
- **v3.3 is the destination:** implement certified placement, approximation/tolerance contracts, deterministic decision semantics, profiles/artifact identity, rejection reasons and ManufacturingSpec according to the reviewed R3 contracts.
- **Grok is a minor optional donor:** evaluate the bounded grammar and BigInt predicate inside their owning v3.3 blocks. Grok is not a required phase, architecture, search layer or second authority.

## Donor admission rule

For each Grok ingredient:

> Adopt only when adapting and proving it is materially smaller than implementing the v3.3 contract cleanly.

- If adoption deletes work and preserves one authority: integrate behind the v3.3 contract.
- If adaptation cost is equivalent: implement the v3.3 block cleanly.
- If it creates dual authorities, adapters around known defects or parallel mechanics: reject it.

Expected disposition:

- arrangement grammar: likely useful as a bounded topology helper;
- BigInt `discFits`: initially useful as an independent reference oracle; production adoption only after equivalence and contract adaptation;
- Grok collector/search/judge/spec/bridge/UI: rejected.

## Minimal assembly-plan change

1. Replace the “three-track Frankenstein” framing with **v3.2 → v3.3 controlled completion**. Source attribution remains in the implementation ledger; it does not define architecture.
2. Remove mandatory “Grok donor extraction” as a parent phase. Put each donor evaluation inside its owning v3.3 work block:
   - exact predicate evaluation inside certified geometry;
   - grammar evaluation inside arrangement topology;
   - behavioral fixtures inside the regression gate.
3. Build **required certified placement before deleting the old sweep** and before packaging/output work. A provisional fast search cannot become the package substrate while the no-missed-seat proof remains a later phase.
4. Keep v3.2 judgement explicitly provisional and fixture-gated. Replace or recalibrate mechanics only through Dan-authoritative canon and counterexamples.
5. Preserve the six-state donor rule: extraction never closes adaptation, proof, integration, canon, parent phase or block.
6. Keep one production authority per operation:
   - v1 validation remains legality authority until an equivalence-approved replacement lands;
   - v3.3 contracts own placement and determinism;
   - Dan-authoritative fixtures own canon;
   - Grok outputs are falsification/reference evidence only.

## Recommended sequence

```text
0. Close v3.2 base repairs and Dan-authoritative canon gate
1. Implement v3.3 certified geometry and complete placement
   - evaluate BigInt predicate and grammar inside this work; adopt only if they reduce it
2. Integrate fixture-gated judgement on the new complete candidate surface
3. Cut the portable package from the proven live subgraph
4. Add deterministic ManufacturingSpec, profiles and rejection reasons
5. Run production performance, byte-determinism and real-surface gates
```

The existing sweep remains as an A/B oracle until Step 1 passes correctness, canon and performance gates; then it is deleted. No parallel production path survives.

## Completion semantics

Examples:

```text
Grok grammar extracted              != candidate-generation block complete
BigInt oracle equivalence passed    != certified geometry complete
Certified placement tests pass      != product integration complete
Canon fixtures pass current output  != Dan-authoritative canon complete
Package builds                      != production engine complete
```

Every original v3.3 acceptance criterion remains attached to its owning block.

## Necessity and sufficiency

**Necessity:** this removes a mandatory donor phase and avoids adapters around code already proved unsafe. Existing validated v3.2 code is retained; genuinely new v3.3 capability is built once.

**Sufficiency:** the direction still covers the complete production directive: fast and certified placement, product judgement, portable package, studio integration and reproducible manufacturing output. Grok's optional status removes no required capability because v3.3 owns every requirement independently.
