# Round 1 — independent engine adjudication

**Lane:** s62-grid-qa

**Date:** 2026-08-15
**Verdict:** **REVISE.** The consolidated-engine direction is right; the present donor claims and transplant plan are not safe to execute as written.

## Exact surfaces audited

- Grok baseline reviewed by Meta: `210c5399f1cf966b7972f4dce444329c682f5eb8`.
- Grok completed selector rebuild: `e735dfbf9a4767b52987e0b5fb67b5a6669b424a` (`select.ts` plus 12 new selector tests; candidate machinery byte-unchanged from `210c5399`).
- Kai v3.2 pre-fix build: `d420b7e5`.
- Kai v3.2 rework: `541a6f40d3694dd38d6dbbfd3b533714d520c7a9`.
- Grok runtime: isolated `e735dfbf` worktree on port 4412; PID/worktree/HEAD verified before inspection.
- v3.2 runtime: isolated `541a6f40` worktree on port 3064; PID/worktree/HEAD verified before inspection.

I read the complete Grok engine, its four test files, and its grid-engine page/canvas integration; the complete v3.2 changed engine files and review document; and the two current assembly plans. Meta's Grok review was not read before this verdict was fixed.

## 1. Grok engine

### Verdict

**Not transplant-grade as a candidate-generation unit.** One low-level predicate is valuable. The grammar is useful research code. `candidates.ts` cannot be copied unchanged into the product engine because it can publish a physically false seat and publishes incorrect parity metadata at scale.

### Blocking findings

1. **The production path proves fit against a lossy outline, not the supplied outline.** `thinForFit` drops vertices closer than 1mm and `makePrepAt` feeds that altered ring into the fit oracle (`candidates.ts:90–116, 160–168, 306–320`). My concave-notch fixture is rejected against the full ring but emitted as a legal centre seat after thinning:

   ```text
   directNotchedFit=false
   emittedNotchedCenter=true
   ```

   The BigInt predicate itself is exact for the ring it receives; the shipping collector gives it a non-conservative ring. “Exact fit” is therefore false at the engine boundary.

2. **Arrangement parity exists but is not wired into candidates.** `registrationOf` correctly derives odd/even axis parity (`enumerate.ts:63–71`). Candidate emission instead derives registration from the lattice origin (`candidates.ts:57–59, 274–301`). Independent sweep on a square:

   ```text
   candidates=31,723
   registration mismatches=24,741
   sample: one-site candidate declared y=gap; arrangement parity requires y=point
   ```

3. **The grammar is generative but bounded, not “any lawful arrangement.”** Runs stop at nine sites (`enumerate.ts:103–110`), stems stop at three (`233–263`), and full windows are disabled above twelve held sites (`268–300`). Probe: ten collinear held sites produce a longest run of nine; thirteen held sites produce zero full windows.

4. **The coarse-then-binary search is not a completeness proof.** `smallestWhere` samples every 12mm and binary-searches the preceding interval (`candidates.ts:171–195`). This assumes the family predicate is monotone over size. That assumption is neither stated nor proved for a fixed lattice/registration over arbitrary non-convex outlines. It returns integer millimetres, not a certified tolerance result.

5. **The current selector is lexicographic, but it is not Dan's calibrated law implementation.** The rebuild removed the weighted primary choice. It still uses bbox-third “mass” (`select.ts:74–87`), a 24-scanline symmetry surrogate (`165–190`), hard-coded thresholds (`9–18`), origin-derived parity from the defective candidate record, and no v3.2 structure classifier. Its own bench reports residual canon misses: Bat B2 108 instead of 88; Duck B4 167 instead of 152; Bot B4 four corners instead of the six-seat fill; Poke1 B3 pair instead of the four-seat square.

6. **Performance passes a loose test, not the assembly gate.** All 71 tests pass. The isolated 4,000-vertex test took 2.067s in a focused run. That is below its test ceiling of 4s, but above the assembly plan's whole-shape `<1s` Phase-1 gate before selection, four bands, and UI work are counted.

### What survives

- Keep the micron-quantized, divide-free `discFits` predicate after defining the quantization/tangency contract and feeding it the full ring or a certified conservative-inward approximation.
- Keep grammar families as bounded enumeration helpers after making bounds explicit and either proving completeness for the released vocabulary or naming the excluded arrangements.
- Do not transplant `thinForFit`, origin-derived registration, or `smallestWhere` as correctness machinery.
- Do not use Grok's judge as a twin authority. It is a useful independent falsifier only after both engines consume the same formal law inputs and canon fixtures.

## 2. Kai v3.2 engine

### Verdict

**Solid enough to complete, not solid enough to preserve unchanged.** The v1 compute core, bench, integration door, and repaired hold/guard logic are the best base. The current search and judgement are provisional implementation, not canon authority.

### Verified repairs at `541a6f40`

- Strip connectivity is true single-linkage connectivity. Probe: two disconnected pairs fail; a three-point chain passes.
- Fallback now relaxes preference filters only and never emits a top/bottom/connectivity-rejected placement (`judgement.ts:583–599`).
- Calibration templates, steps, and tuples are deeply frozen; invalid numeric and option writes refuse explicitly.
- Classifier geometry moved into `compute/structure.ts`.
- Suite: 35/35 green.

### Remaining material defects

1. **The “canon-validated judge” claim is false on the reworked commit.** Independent seven-shape live walk at `541a6f40` produced:

   | Shape | B1 | B2 | B3 | B4 |
   |---|---:|---:|---:|---:|
   | Bat | 60 | 88 | 146 warning | 170 warning |
   | Bot | 44 | 98 | 144 | 168 warning |
   | Butterfly | 68 | 92 warning | 126 | 204 warning |
   | Duck | 60 | 84 | 154 | 178 warning |
   | Pill | 54 | 82 | 120 | 168 / 3pt warning |
   | Poke1 | 40 | 76 | 126 warning | 172 / 4pt warning |
   | Poke2 | 44 | 76 | 124 | 190 warning |

   Ten of 28 frames still warn. Pill B4 and Poke2 B3 contradict the document's pinned scorecard. A table that changes with ranking calibration is not a canon gate.

2. **Runtime remains far from mobile.** The full suite took 134.73s. The deterministic-twice case alone took about 65s; square and concave cases took about 37s and 32s. Passing tests do not satisfy the product latency requirement.

3. **Separation improved but is not complete.** `logic/judgement.ts` still owns resolution/policy literals (`STRUCTURE_SCANLINES=24`, `MASS_FIELD_SAMPLES=40`, a 72mm footprint threshold) and uses them to compute the decision inputs (`judgement.ts:173–194, 278, 614–631`). The separation tests do not detect those values.

4. **The sort comparator violates the comparator contract for equal rows.** `kept.sort((a,b) => better(a,b) ? -1 : 1)` never returns zero (`judgement.ts:537`). Exact duplicates can compare `+1` in both directions. Determinism must be proved with a total key or a comparator that handles equality explicitly.

5. **The repaired behaviours lack direct regression tests.** The 35-test suite passed, but the connectivity, guarded calibration writers, and lawful fallback repairs were established by my probes, not by named tests that would fail if those fixes regress.

6. **The 108mm strip value is not the stated “sparse lattice diagonal.”** `sqrt(48²+96²)=107.3` is a mixed 48×96 rectangle diagonal. A 96×96 sparse diagonal is 135.8. If 108 exists to preserve the ruled triangle, say that; the current geometric label is wrong.

### What survives

- Keep the byte-identical v1 compute core, its validation door, the bench, and the repaired connectivity/fallback/guard work.
- Keep the law categories as hypotheses encoded in fixtures, not as frozen judgement code.
- Replace the sweep/search and close the continuous/certified placement requirement.
- Recalibrate or replace decision mechanics only behind executable 28-frame canon fixtures and counterexamples.

## 3. Meta claim adjudication

### Grok claims

| Claim | Verdict |
|---|---|
| BigInt micron, divide-free exact disc fit | **True only for the prepared ring. False for collector correctness because the collector first performs unsafe 1mm thinning.** |
| Generative grammar | **True.** |
| “Any lawful arrangement” | **False.** Hard caps exclude lawful large runs/windows/stems. |
| Coarse 12mm then exact/binary refinement | **Mechanically true; “exact” and completeness are overstated.** It resolves integer mm under an unproved monotonicity assumption. |
| Odd/even parity on every candidate | **False.** 24,741/31,723 mismatch probe. |
| Behavioural fixtures exist | **True.** They do not cover the two candidate blockers above. |
| Selector is a weighted blend | **True at `210c`; superseded at `e735`.** The new selector is lexicographic but still not canon-equivalent. |
| Candidate files are pure/dependency-free/trivially portable | **Overstated.** They avoid React/Next, but `candidates.ts` depends on four local engine modules and is unsafe to transplant unchanged. |
| 4,000 vertices under 4s | **True on the narrow test (2.067s here); insufficient for the `<1s` assembly gate and mobile target.** |
| Candidate machinery is transplant-grade | **False.** |

### v3.2 claims

| Claim | Verdict |
|---|---|
| Only track producing the ruled shapes on a working bench | **Substantially true.** It remains the strongest integration base. |
| Calibrated, canon-validated judgement; keep unchanged | **False.** Ten live warnings and scorecard drift at `541a6f40`. |
| Byte-verbatim v1 compute core | **True for the seven lifted core files checked against v1.** |
| Strong guards | **Materially true after `541a6f40`; direct regression coverage is missing.** |
| Complete rather than replace | **True for the base, false for the unchanged judge/search.** |
| Four defects only | **False.** Performance, canon authority, decision separation, comparator correctness, and missing regression coverage remain. |

## 4. Assembly-plan correction

The current Frankenstein plan says to copy `measure.ts`, `enumerate.ts`, and the `candidates.ts` search kernel verbatim, keep v3.2 ranking unchanged, and make continuous placement conditional. That composition preserves both engines' demonstrated defects.

**Minimal correction:**

1. Phase 0 first freezes the 28 canon frames and counterexamples as executable fixtures. No “currently verified defaults” may silently substitute for Dan's ruled frames.
2. Transplant only Grok's exact predicate and bounded grammar after fixing the full-ring/conservative-approximation and parity contracts.
3. Do not transplant `thinForFit` or treat `smallestWhere` as a no-missed-seat proof.
4. Keep v3.2's core/bench/repaired holds, but put its judge behind the fixture gate; “ranking unchanged” is removed.
5. Continuous or otherwise certified complete registration is not conditional on a speed miss. It is required by the precision directive unless a different algorithm proves the same no-missed/no-false-seat contract.
6. The twin-oracle protocol compares outcomes but cannot confer authority: agreement between two surrogate judges is not canon evidence.

## Necessity and sufficiency

**Necessity:** shrink the plan by removing unchanged transplantation of `thinForFit`, origin parity, the unproved snug search, and unchanged v3.2 ranking. The surviving donor set is the smallest defensible base.

**Sufficiency:** the present plan is partial against “super-precise” and “canon-faithful.” The six corrections above are required before Phase 1 can start; package/output work remains valid after the engine gate closes.

## Evidence

- Grok code/tests: isolated `e735dfbf`; 71/71 green in 1.55s.
- Grok focused 4,000-vertex test: 2.067s.
- Grok adversarial probe: exact tangency boundary passes; 24,741 parity mismatches; capped grammar; full-ring false / collector-emitted true notch case.
- Grok visual gate: seven saved cutouts exercised on the real `snap-48` bench at port 4412; screenshots in `/tmp/grok-e735-visual/`.
- v3.2 code/tests: isolated `541a6f40`; 35/35 green in 134.73s.
- v3.2 adversarial probes: connectivity, fallback prerequisites, deep-freeze, numeric/option refusal.
- v3.2 visual gate: seven cutouts × four bands on the real bench at port 3064; screenshots in `/tmp/v32-541-visual/`.

## 5. Reconciliation with Meta's independent Grok review

Read only after Sections 1–4 were written. Meta correctly identified the baseline selector's weighted blend, forced band counts, midpoint gravity proxy, absent per-side wrap, and missing law categories. Its central conclusion—“candidate machinery is strong; only `select.ts` is wrong”—does not survive source execution.

Meta missed four donor blockers:

1. `thinForFit` makes the shipping fit decision against an unsafe altered outline; my notch fixture proves a false legal seat.
2. `registrationOf` is correct dead data for candidate emission; the collector's origin-derived field disagrees on 24,741 of 31,723 candidates.
3. “Runs any length” and “provable coverage” are false under explicit caps of nine run sites, three stem sites, and twelve held sites for windows.
4. The 4,000-vertex test takes 2.067s here, so it does not establish the proposed sub-second product path.

The completed `e735dfbf` rebuild addresses Meta's weighted-selector criticism only. It does not repair those candidate defects. It also treats top/bottom hold as ordering preferences rather than legality filters: if every candidate fails a hold, one still wins. Its precedence additionally inserts bbox-third mass coverage and corners ahead of sparse/axis/tightness, so it is not the exact sequence Meta prescribed. The current bench's four admitted canon residuals confirm that the rebuild did not close the engine gate.

**Reconciled verdict on Meta's Grok review:** correct diagnosis of the old judgement layer; materially incomplete and unsafe as a transplant recommendation.
