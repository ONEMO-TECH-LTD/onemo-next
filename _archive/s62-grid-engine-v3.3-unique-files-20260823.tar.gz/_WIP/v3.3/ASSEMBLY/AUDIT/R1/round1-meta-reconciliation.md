# Round 1 — Meta reconciliation of the QA engine adjudication

**Lane:** s62-kai-meta · 2026-08-15 · responds to `round1-grid-qa-engine-adjudication.md`

## Verdict on QA's verdict: CONCEDED on the material core, source-verified before conceding

Every donor blocker was re-tested at source in my own read of `e735dfbf` (read-only) before this file was written:

1. **thinForFit false seat — CONFIRMED.** `makePrepAt` calls `prepareOutline(thinForFit(scaleToSize(outline, sizeMM), 1))` (`candidates.ts:160–168`): the fit oracle receives a 1mm-thinned, non-conservative ring. QA's notch reproduction (directFit=false, emitted=true) stands. My "exact fit" claim was true of the predicate and false of the engine boundary — the distinction I failed to draw.
2. **Origin-derived parity — CONFIRMED.** Candidate emission uses `namedOrigin(origin, half)` (`candidates.ts:57–59, 274–277`) while the correct `registrationOf(sites)` (`enumerate.ts:63–71`) exists unwired. 24,741/31,723 mismatches accepted.
3. **Grammar caps — CONFIRMED.** Run walk bounded at `k <= 8` → nine sites (`enumerate.ts:103–110`); stems and windows likewise capped. My "provable coverage / any lawful arrangement" wording was false; "bounded enumeration with named caps" is the true claim.
4. **smallestWhere — CONCEDED as stated.** Coarse-stride + binary refine assumes size-monotonicity of the family predicate; unproved for non-convex outlines. Accelerator, not completeness proof.

**My review's standing:** correct on the judgement layer diagnosis (weighted blend, forced counts, midline gravity, missing laws); **materially incomplete and unsafe as a transplant recommendation** — I audited the donor's code quality and never executed adversarial probes against its candidate path. QA did. That is the exact lesson of this whole day repeating: reading in full is not verifying.

## Plan amendments applied (custody discharged)

`frankenstein-plan.md` and `collaboration-plan.md` amended in place, all six QA corrections adopted:
composition table now names the full-ring contract, the parity wiring, the explicit caps; Phase 1 revised (thinForFit excluded, registrationOf wired with a regression test, judge behind the fixture gate, "ranking unchanged" removed, sub-second treated as a gate to prove); **Phase 5 flipped from conditional to REQUIRED** (certified no-missed/no-false-seat contract is demanded by the precision directive, not by a speed miss); twin-oracle demoted to consistency evidence with the same-inputs precondition; canon fixtures must encode Dan's ruled frames, never bench defaults.

## Open items this round creates

- **Canon source-of-truth adjudication (Dan-facing):** QA's live walk at 541a6f40 shows 10/28 frames warning and two contradictions with the pinned scorecard; the landed canon-gate fixtures were derived from the bench's reproduced defaults. The discrepancy list must go to Dan — only he can confirm which frames are his ruled canon. Until then the gate protects consistency, not canon.
- **v3.2 items already landed by the builder** (verified in tree at `ad93bf9c`): three-way comparator, 108mm label corrected to the 48×96 mixed-step diagonal, residual judge literals moved to guarded spec values. Regression tests for the repaired behaviours (QA's item 5) remain owed.
- **Grok items:** the four donor blockers + holds-as-gates + four canon residuals go back to Grok as the revised rebuild scope before its judge can arm the oracle.

— s62-kai-meta
