# T0/T0b — Meta close verdict

**Lane:** s62-kai-meta · 2026-08-16 · closing gate after QA CLEAR @ 0a8d98bf on builder commit `97313324`.

## Verdict: REWORK — bounded, two rows plus one sweep. Not a CLEAR.

The ledger is strong work and QA's five-round gate got it most of the way. Necessity and sufficiency
both hold. It fails on the one bar I stated before the build started: **a RULED row must reach Dan's
own words.** I walked the six vault-cited RULED rows back to source myself; four verify exactly, two
do not.

## What I verified, by walking the citation (not by reading the claim)

| Row | Citation | Result |
|---|---|---|
| 1.8 operating floor 1 mm | lead 2026-08-11 `_day.md:4329` | **VERIFIED** — line exists, Dan's turn, wording matches |
| 1.5 sparse hides points, nothing re-centred | meta 2026-08-11 `_day.md:275` | **VERIFIED** — Dan's turn, exact |
| 2.6 no band-count rule | kai 2026-08-16 `_day.md` | **VERIFIED** — Dan's turn, read in full myself |
| 7.2 all distinct optima, one marked | kai 2026-08-16 `_day.md:219` (10:52:27) | **VERIFIED** — Dan's turn; the normalization already correctly marked as derivation |
| **3.1 square is the standard, rectangle derivative** | "(V) Dan 08-16, this lane's day-file" | **FAILS** |
| **6.7a flap switch is method, not ruling** | "(V) Dan 08-11 10:32, meta lane day-file" | **FAILS** |

## F1 — Row 3.1: the quoted sentence is not a Dan turn

`grep -rn` across the entire vault for the quoted text and its fragments returns **only the builder's
own restatements** (kai `_day.md:690` and `:725`, and the same lines in segment `1-s62-kai--00-17.md`)
— i.e. the lead's message, not Dan's. No Dan turn contains it.

**Not baseless, but wrongly routed.** Dan's own words do support the square standard existing:
`grid-brief.md:1105` — *"recalculate long side of the image in 3 bands of grid sizing I asked as per
square standard"* — a valid **(B)** route. What is *not* his is the derivation chain ("rectangle is
derivative and anything else walks from there").

**Correction:** re-source 3.1 to **(B) `grid-brief.md:1105`** for the square standard; mark the
rectangle/circle/free-class derivation chain as **derivation** (the same treatment 7.2 already
received). No engineering change — 3.3/3.5/3.6 already carry their own arithmetic and CALIBRATED
routes.

## F2 — Row 6.7a: a lane restatement classified RULED

The quoted sentence appears three times in the vault and **every one is a lane quoting Dan inside its
own message** (lead 2026-08-13 `_day.md:3185`, `:3195`; lead 2026-08-14 segment `:67`) — none is a
captured Dan turn, and none is in the meta 08-11 day-file the row cites.

**The ledger's own convention already decides this:** *"Where a ruling exists only as a lane relay
(the collector drops mid-turn messages), it is marked **(R)** and treated as **CALIBRATED**, not
RULED."* The content is very likely genuine — two lanes quote it consistently across days — but the
capture does not exist, so the row must take the route its own rule assigns.

**Correction:** reclassify 6.7a to **(R) → CALIBRATED**, owner s62-kai, citing the two lane
restatements as its provenance. Note this **strengthens** the row's obligation rather than weakening
it: as CALIBRATED it must be proven by the T7 measurement, which 6.7b already schedules.

## F3 — The systemic point: fix the class, not the instances

QA caught exactly this defect once, at 7.2, and it was repaired precisely — but **no sweep of the
other (V) rows followed**, so the same class survived at 3.1 and 6.7a. That is the third time today a
correction landed on the named instance without the class being swept.

**Required with F1/F2:** walk **every** (V), (B) and (D) citation in the ledger back to source and
record the result inline — a row whose quote cannot be located becomes (R)/CALIBRATED or is
re-sourced, never left as RULED. Cheap: `grep -rn "<quote>" "$VAULT"` per row, and the ledger already
carries the routes to check. This is a bounded sweep inside T0, not a new task.

## What passes, and passes well

- **No code entered T0.** Verified independently: `git diff --name-only ca33f42a~1 97313324` returns
  the two ledger files only; `src/lib/grid-engine/**` untouched across every T0 commit.
- **No manufactured Dan gate.** §10 holds exactly one residual — the uploaded contour's identity —
  correctly scoped to the final replacement gate only, with the search that was done recorded. Five
  formerly-"open" items are resolved from source, and the bat-B4/B5 question is honestly withdrawn as
  premature rather than parked on Dan.
- **The four traps I named in advance are all in §9 displaced**, each with the correct winner: the
  B4 40 mm allowance, the ≥24 mm separation, cross-band out-counting, universal `targetMagnets` —
  plus seven more I had not named, including `sideHangMM` and the L18 legality clause.
- **The mechanics registry now carries the completeness invariant per descriptor**, with coverage and
  distribution correctly identified as piecewise-constant over `F` (requiring a certified partition,
  not a sampled registration), unsupported extent's interior-optimum counterexample accepted, and
  peel leverage's convexity explicitly **not** claimed. Balance is the one row whose completeness
  argument is established rather than deferred — and it says so.
- **8B.2 withdraws its own over-reach**: the earlier "permitted iff" is replaced by two *necessary*
  constraints with an explicit statement that they are not sufficient and not the matrix.
- **§11's crosswalk replaced self-certifying checkmarks with a walkable mapping**, and its scope
  statement withdraws the completeness claims it cannot support. Implementation obligations are now
  mapped to the task that *builds* them, not to T7 which only verifies.

## Necessity / sufficiency

**Necessity — no unnecessary elements.** The ledger records rules and their routes; nothing in it
exists that a named task does not consume, and §9 is genuine subtraction with eleven mechanisms
displaced by authority rather than opinion.

**Sufficiency — partial, and only on provenance.** Every input T4/T5/T6 consumes has a row; the
engineering content is complete. The gap is that two RULED rows do not reach Dan's words, which is
the exact property the ledger exists to guarantee. Fix F1–F3 and it delivers T0 in full.

**T1 stays blocked.** Correction goes to the builder; QA re-gates; I close on the successor.

— s62-kai-meta
