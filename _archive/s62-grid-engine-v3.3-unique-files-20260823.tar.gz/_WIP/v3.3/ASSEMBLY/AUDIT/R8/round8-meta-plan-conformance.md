# Round 8 — Meta conformance verdict on the v3.2 consolidated plan

**Lane:** s62-kai-meta · 2026-08-16 · Dan-directed: *"find 3.2 last qa report and kai's report — final
proposal must conform fully to prior findings and plan must be based on that."*

**Read in full:** the lead's 2026-08-16 day-file (1,065 lines, end to end) · QA's
`v3.2-code-logic-audit.md` (257 ln) · QA's `v3.2-final-conformance-verdict.md` (217 ln) · the lead's
`v3.2-consolidated-plan.md` (189 ln) · its superseded predecessor `v3.2-completion-proposal.md`.
**Verified in the tree:** head `36cbc463`, dirty `judgement.ts`; commit ancestry
`9123ba3d → 6b2f11ae → 4bf5043a → 2c213143 → docs…`.

## Verdict: CONFORMANT IN SUBSTANCE — with four corrections before it governs

Every P0/P1/P2 finding in QA's two reports is carried into the plan, and every place QA corrected the
lead is recorded openly in its §7 rather than buried. Traced one by one:

| QA finding | Plan clause |
|---|---|
| P0 phase door broke protected lower bands | Step 0 restore + §3 REPLACE |
| P0 bat B4 not a stepped tight optimum | Step 2 certified placement + §8 open decision |
| P0 tightness computed, never governs; `tier` unsound | Step 3 (wrap facts before structure/spread; tier **not** carried over) |
| P0 distinct scale/window optima discarded | Step 3 result identity = window+registration+profile+artifact; equal-count valid |
| P0 previous band truncates next band's search | Step 3 "no cross-band truncation" |
| P0 side-mass proxy dimensionally unstable | §3 REPLACE |
| P0 B4 silently weakens the top law (40mm) | §3 DELETE + §7 (marked inference) |
| P1 fallback manufactures an optimum | Step 3 "no fallback manufactures an optimum" |
| P1 search not product-viable (42s vs 16ms) | Step 2 acceptance: measured runtime against the gate |
| P1 acceptance oracle stale/incomplete | Step 1 rebuild from rulings + the uploaded contour |
| P2 variant UI key incomplete | Step 5 chip key = stable result identity |
| Focus spec contradictions | §6, with "governs nothing until resolved" |
| Canon fixtures are not authority | §1 authority order |

Necessity and sufficiency both hold on the plan's own axes: nothing is rewritten that works (geometry
kernel, bridge, guards, UI preserved), the deletions are genuine subtraction, and the deferrals in §5
are named rather than smuggled.

## The four corrections

**C1 — Step 0's restore target still contains two mechanisms the plan itself deletes.** `9123ba3d` is
not a clean pre-door baseline: its own commit title is *"grid-growth door + stepped-band growth
ladder"*. Removing `6b2f11ae`/`4bf5043a` removes the **phase-enumerated** flood, the side proxy and the
40mm exception — correct — but the restored base still carries the original row/column growth door and
the increasing-count ladder, both of which §3 lists for replacement/deletion. Step 0 must say so: it is
the **least-wrong measured base (7/7 canon per QA), not a good state**, and its residual door + ladder
retire in Steps 2–3. Otherwise a later reader treats the restore point as endorsed.

**C2 — the plan carries no disposition for the dirty tree.** `judgement.ts` is modified and uncommitted
right now (the mass-tier/label edit). Step 0 must state explicitly: commit it as a labelled snapshot or
discard it — the plan cannot start from an unrecorded state, and the standing snapshot law forbids
leaving it.

**C3 — MISSING PRIOR FINDING: the R3 certified-placement contract has now been executed on real
traces, and it refuses.** Step 2 says "implement the R3 certified-placement contract" as if untested.
It is not untested — GPT Pro's build *is* that contract implemented, and my Round-6 audit measured it
(own runs, real bat trace ≈3,000 vertices):
- `certifySizeSolution` returned **DECISION_INDETERMINATE** at both 60mm (M03 upper moment, 23.3s) and
  96mm (M01 major coverage, 54.9s) — the certification path cannot certify a real cutout at the
  contract's own tolerances;
- preview solves ran **18–36s per shape** on all seven canon shapes, i.e. the same order as v3.2's 42s —
  because that implementation has no spatial acceleration at all (linear edge scans, O(n²) preparation).
**Consequence for the plan:** Step 2's acceptance must add two criteria — (a) the certified path must
return a certified optimum, not INDETERMINATE, on the real canon contours at product vertex counts, and
(b) the feasibility search must run on v3.2's **accelerated** predicates (v1's BVH/interval-tree
distance and containment), never fresh linear ones. Without (a) the plan can pass its own gate while
producing an engine that refuses every real order; without (b) it reproduces the 18–36s wall measured
in the reference implementation.

**C4 — carry the positive evidence too.** The same audit ran five adversarial attacks against that
contract's adaptive feasibility engine — exact-width (zero-area) corridor, one-quantum-too-narrow
corridor, the concave notch that produced a false seat in Grok's engine, a starved 200-cell budget, and
a ±0.01mm hairline seat window. **All five survived: no false seats, no missed seats, honest
degradation.** The architecture Step 2 adopts is attack-proven; that belongs in the plan as the reason
the boundary is drawn there, so a future reviewer does not reopen it.

## Two provenance notes (no change required, record only)

- The **16ms/50ms** gate is the R3 *provisional* engineering target, not a Dan ruling; the plan cites it
  as a gate. Correct to measure against it; it should not become a blocking law without his word.
- QA's verdict text names "the delivered v3.3.1 architecture" as the replacement. That artifact is dead
  (byte-identical repair delivery, verified by both lanes; Dan: *"gpt pro failed we moved on"*). The
  plan's substitution — implement the contract in-house — is the correct reading of the same finding.

## Bottom line

The plan is based on the prior findings and does not drift from them. With C1–C4 applied it conforms in
full, and the one open item genuinely belonging to Dan — whether bat band 4 has an answer inside
168–216 or is honestly a B5 — is correctly left to him.

— s62-kai-meta
