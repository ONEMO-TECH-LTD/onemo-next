# Assembly — collaboration plan

**Companion to:** `frankenstein-plan.md` (v3.2 base → v3.3 destination). This file adds WHO and HOW. Dan-directed, 2026-08-15.
**The lanes:** @s62-kai (builder/lead, v3.2 worktree) · @s62-grid-qa (adversarial gate) · @s62-kai-meta (plan custody + step gates). **Grok is rejected from this build; its prior findings remain audit evidence** (`AUDIT/R1/`).

## Roles

**@s62-kai — the builder.** Owns the v3.2 worktree, the bench, and every merge into it. Executes Steps 0–5 of the reframed plan: Step 0 base repairs + harness (landed; three narrow QA closure gaps open — count-guard integrality, fallback execution proof, boundary-claim scope), then Step 1 certified geometry + complete placement — clean implementation, the old sweep surviving as the A/B oracle until Step 1 passes its gates — then fixture-gated judgement, package cut, output contracts, production gates. One snapshot per step, pushed.

**@s62-grid-qa — the gate.** Nothing crosses a step boundary without QA's adversarial pass: canon fixtures verified frame-by-frame on the running bench (3063), claims attacked with own probes, the counterexample suite co-owned with the builder, byte-determinism checked on the Step-4 output contracts and Step-5 production gates. QA's REVISE findings stay open until QA itself closes them — the builder does not self-clear them.

**@s62-kai-meta — plan custody and arbitration.** Necessity/sufficiency verdict at each step gate (is the step's diff minimal AND complete); custodian of the plan documents (changes go through me, so the lanes never build to different versions); adjudicator of any falsification evidence filed against canon; custodian of the short real-decision list for Dan (the seven canon rulings · PD-38 tolerance question · Batwoman vector blessing).

## Dependencies and sequence (matches frankenstein-plan.md steps)

```
Step 0  base repairs + harness ✅ landed & meta-verified   OPEN: Dan's 7 canon rulings re-pin the gate
Step 1  builder: v3.3 certified geometry + complete placement — clean implementation
        (old sweep stays as A/B oracle until Step 1 passes correctness+canon+perf — then deleted)
        QA gates · meta necessity/sufficiency
Step 2  builder: fixture-gated judgement on the complete candidate surface
        QA sweeps · meta arbitrates
Step 3  builder: package cut                        meta: necessity gate (dormant surface named)
Step 4  builder: ManufacturingSpec + reasons        QA: byte-determinism
Step 5  production gates (perf, determinism, real surface)   Dan: bench reviews (end of 1, and 4)
```

Canon discrepancies are resolved by the team under the conflict rule (more recent / better
evidenced source wins, choice documented), re-pinned in the fixtures, and flagged visibly on the
bench for Dan's veto — they are not questions for Dan and do not block the build.

## Rules of engagement

1. **No lane touches another lane's worktree.**
2. **All coordination through kai-msg**, addressed by handle; long content as a file + path. Build questions → builder; gate verdicts → the gate owner; plan changes → meta; outcomes → Dan.
3. **Every claim execution-backed**: no "verified" without the frame seen on the current commit; a ✓ expires when the ranking changes (the builder's own standing rule — now the team's).
4. **Canon-fixture failure blocks any merge. No exceptions, no one self-clears their own gate.**
5. Dan's touchpoints: **the seven canon rulings + the go, which gate everything past Step 0** (the Step-0 hold is absolute — nothing builds before them); then bench reviews at end of Step 1 (same canon, certified placement, new speed) and Step 4 (spec output); the tolerance question (PD-38) whenever he chooses — it alone does not block.
